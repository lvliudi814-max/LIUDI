#!/bin/zsh
set -euo pipefail

installer_dir="${0:A:h}"
plugin_source="${installer_dir}/feishu-minutes-sync"
suggested_vault="${HOME}/Documents/Obsidian Vault"

read_manifest_version() {
  local manifest_path="$1"
  local version=""
  if [[ -f "${manifest_path}" ]]; then
    version="$(/usr/bin/sed -n 's/.*"version"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p' "${manifest_path}")"
  fi
  print -r -- "${version:-未知}"
}

validate_plugin_dir() {
  local plugin_dir="$1"
  [[ -f "${plugin_dir}/manifest.json" \
    && -f "${plugin_dir}/main.js" \
    && -f "${plugin_dir}/resources/obsidian_gate.py" \
    && -f "${plugin_dir}/resources/Glossary｜飞书妙记术语校准表.md" ]]
}

clear 2>/dev/null || true
echo "飞书妙记同步插件安装 / 更新"
echo ""
echo "请先完全退出 Obsidian。"
echo "请输入 Obsidian Vault 文件夹路径，也可以把文件夹拖到本窗口。"
if [[ -d "${suggested_vault}/.obsidian" ]]; then
  echo "直接按回车将使用：${suggested_vault}"
fi
printf "> "
IFS= read -r vault_path

vault_path="${vault_path%\"}"
vault_path="${vault_path#\"}"
vault_path="${vault_path%\'}"
vault_path="${vault_path#\'}"
vault_path="${vault_path//\\ / }"
vault_path="${vault_path% }"
if [[ "${vault_path}" == '~/'* ]]; then
  vault_path="${HOME}/${vault_path#\~/}"
fi
if [[ -z "${vault_path}" && -d "${suggested_vault}/.obsidian" ]]; then
  vault_path="${suggested_vault}"
fi

if [[ ! -d "${plugin_source}" ]] || ! validate_plugin_dir "${plugin_source}"; then
  echo "安装包不完整：找不到 feishu-minutes-sync 插件文件夹。"
  if [[ -t 0 ]]; then read -k 1 -s '?按任意键关闭...'; fi
  exit 1
fi

if [[ -f "${plugin_source}/data.json" ]]; then
  echo "安装包异常：包内不应包含 data.json，已停止安装。"
  if [[ -t 0 ]]; then read -k 1 -s '?按任意键关闭...'; fi
  exit 1
fi

if [[ -z "${vault_path}" || ! -d "${vault_path}/.obsidian" ]]; then
  echo "没有找到有效的 Obsidian Vault：${vault_path:-未输入}"
  echo "请确认所选文件夹内存在 .obsidian 目录。"
  if [[ -t 0 ]]; then read -k 1 -s '?按任意键关闭...'; fi
  exit 1
fi

plugins_dir="${vault_path}/.obsidian/plugins"
plugin_backups_dir="${vault_path}/.obsidian/plugin-backups"
plugin_target="${plugins_dir}/feishu-minutes-sync"
install_stamp="$(date '+%Y%m%d-%H%M%S')-$$"
plugin_stage="${plugins_dir}/.feishu-minutes-sync.installing-${install_stamp}"
new_version="$(read_manifest_version "${plugin_source}/manifest.json")"
old_version=""
plugin_backup=""
settings_preserved=false

if [[ -e "${plugin_target}" && ! -d "${plugin_target}" ]]; then
  echo "安装目标已存在但不是文件夹：${plugin_target}"
  echo "为避免覆盖数据，已停止安装。"
  if [[ -t 0 ]]; then read -k 1 -s '?按任意键关闭...'; fi
  exit 1
fi

if [[ -d "${plugin_target}" ]]; then
  old_version="$(read_manifest_version "${plugin_target}/manifest.json")"
  echo ""
  echo "已检测到旧版本：${old_version}"
  echo "准备安装新版本：${new_version}"
else
  echo ""
  echo "准备首次安装版本：${new_version}"
fi

mkdir -p "${plugins_dir}"

# 0.8.0 及更旧的安装器曾把备份放在 plugins 目录，Obsidian 会将其
# 当成重复插件扫描。先迁移这些旧备份，再进行安装或更新。
legacy_backups=("${plugins_dir}"/feishu-minutes-sync.backup-*(N))
if (( ${#legacy_backups[@]} > 0 )); then
  mkdir -p "${plugin_backups_dir}"
  for legacy_backup in "${legacy_backups[@]}"; do
    legacy_name="${legacy_backup:t}"
    legacy_destination="${plugin_backups_dir}/${legacy_name}"
    if [[ -e "${legacy_destination}" ]]; then
      legacy_destination="${legacy_destination}.migrated-${install_stamp}"
    fi
    if ! mv "${legacy_backup}" "${legacy_destination}"; then
      echo "旧备份迁移失败，原有插件未被改动。"
      if [[ -t 0 ]]; then read -k 1 -s '?按任意键关闭...'; fi
      exit 1
    fi
    echo "已将旧备份移出插件扫描目录：${legacy_destination}"
  done
fi

if ! cp -R "${plugin_source}" "${plugin_stage}"; then
  echo "无法创建安装临时目录，原有插件未被改动。"
  if [[ -t 0 ]]; then read -k 1 -s '?按任意键关闭...'; fi
  exit 1
fi

if ! validate_plugin_dir "${plugin_stage}"; then
  echo "插件复制校验失败，原有插件未被改动。"
  if [[ -t 0 ]]; then read -k 1 -s '?按任意键关闭...'; fi
  exit 1
fi

if [[ -f "${plugin_target}/data.json" ]]; then
  if ! cp -p "${plugin_target}/data.json" "${plugin_stage}/data.json" \
    || ! cmp -s "${plugin_target}/data.json" "${plugin_stage}/data.json"; then
    echo "旧版插件设置保留失败，原有插件未被改动。"
    if [[ -t 0 ]]; then read -k 1 -s '?按任意键关闭...'; fi
    exit 1
  fi
  settings_preserved=true
fi

if [[ -d "${plugin_target}" ]]; then
  mkdir -p "${plugin_backups_dir}"
  plugin_backup="${plugin_backups_dir}/feishu-minutes-sync.backup-${install_stamp}"
  if ! mv "${plugin_target}" "${plugin_backup}"; then
    echo "无法备份旧版插件，已停止更新。"
    if [[ -t 0 ]]; then read -k 1 -s '?按任意键关闭...'; fi
    exit 1
  fi
fi

if ! mv "${plugin_stage}" "${plugin_target}"; then
  echo "新版插件换入失败，正在恢复旧版本…"
  if [[ -n "${plugin_backup}" && -d "${plugin_backup}" && ! -e "${plugin_target}" ]]; then
    mv "${plugin_backup}" "${plugin_target}" || true
  fi
  echo "更新未完成，请继续使用原版本。"
  if [[ -t 0 ]]; then read -k 1 -s '?按任意键关闭...'; fi
  exit 1
fi

if ! validate_plugin_dir "${plugin_target}"; then
  failed_target="${plugins_dir}/feishu-minutes-sync.failed-${install_stamp}"
  echo "新版插件最终校验失败，正在恢复旧版本…"
  mv "${plugin_target}" "${failed_target}" || true
  if [[ -n "${plugin_backup}" && -d "${plugin_backup}" && ! -e "${plugin_target}" ]]; then
    mv "${plugin_backup}" "${plugin_target}" || true
  fi
  echo "更新未完成，失败文件已保留到：${failed_target}"
  if [[ -t 0 ]]; then read -k 1 -s '?按任意键关闭...'; fi
  exit 1
fi

echo ""
if [[ -n "${old_version}" ]]; then
  if [[ "${old_version}" == "${new_version}" ]]; then
    echo "插件修复安装完成：${new_version}"
  else
    echo "插件更新完成：${old_version} → ${new_version}"
  fi
  if [[ "${settings_preserved}" == true ]]; then
    echo "个人设置与已同步记录：已保留"
  else
    echo "个人设置与已同步记录：旧版本未发现 data.json"
  fi
  echo "旧版本备份：${plugin_backup}"
else
  echo "插件安装完成：${new_version}"
fi
echo "插件位置：${plugin_target}"
if command -v lark-cli >/dev/null 2>&1; then
  echo "lark-cli：已检测到"
else
  echo "lark-cli：未检测到"
  echo "请在终端执行：npx @larksuite/cli@latest install"
fi
if command -v python3 >/dev/null 2>&1; then
  echo "Python 3：已检测到"
else
  echo "Python 3：未检测到，使用插件前请先安装。"
fi

echo ""
if [[ -n "${old_version}" ]]; then
  echo "下一步：重新打开 Obsidian，原有设置和已同步记录已保留。"
  echo "如果插件未自动启用，请在‘设置 → 第三方插件’中重新启用。"
else
  echo "下一步：重新打开 Obsidian → 设置 → 第三方插件 → 启用‘飞书妙记同步’。"
  echo "然后进入插件设置，点击‘检查并修复’，使用本人飞书账号完成授权。"
fi
echo ""
if [[ -t 0 ]]; then read -k 1 -s '?按任意键关闭...'; fi
