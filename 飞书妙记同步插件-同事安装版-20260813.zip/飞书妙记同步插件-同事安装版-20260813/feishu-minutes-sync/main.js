const { Plugin, PluginSettingTab, Setting, Notice, TFile, normalizePath } = require("obsidian");
const { execFile, execSync } = require("child_process");
const fs = require("fs");
const os = require("os");
const path = require("path");

const PLUGIN_VERSION = "0.9.1";
const REQUIRED_USER_SCOPES = [
  "offline_access",
  "minutes:minutes:readonly",
  "minutes:minutes.search:read",
  "minutes:minutes.transcript:export",
  "minutes:minutes.artifacts:read",
  "vc:note:read",
  "docx:document:readonly",
  "docs:document.media:download",
];
const CLI_CANDIDATES = [
  "/opt/homebrew/opt/node@22/bin/lark-cli",
  "/opt/homebrew/bin/lark-cli",
  "/usr/local/bin/lark-cli",
];
const NODE_22_BIN = "/opt/homebrew/opt/node@22/bin";

const DEFAULT_SETTINGS = {
  cliPath: "",
  syncFolder: "FeishuMinutes",
  folderGrouping: "none",
  attachmentFolder: "01-会议纪要/FeishuMinutes/assets",
  minutesCleanerScript: "",
  minutesCleanerGlossary: "",
  pollIntervalMinutes: 30,
  autoSync: true,
  lookbackDays: 7,
  includeTranscript: true,
  includeSummary: true,
  includeSmartDoc: true,
  // 智能纪要内各模块独立开关（includeSmartDoc 开启时生效）
  includeSmartSummary: true,
  includeChapters: true,
  includeTodos: true,
  includeDecisions: true,
  includeHighlights: true,
  includeLinks: true,
  includeImages: true,
  includeWhiteboards: true,
  trimImageWhitespace: true,
  includeArtifactBackups: false,
  updateExisting: true,
  backupBeforeEnrich: true,
  debug: true,
  lastBackgroundAuthWarningAt: 0,
  lastFolderOrganization: null,
  syncedTokens: {},
};

class FeishuMinutesSyncPlugin extends Plugin {
  constructor() {
    super(...arguments);
    this.syncing = false;
    this.nodeDir = null;
    this.lastBackgroundErrorNoticeAt = 0;
    this.authRepairMonitorId = null;
    this.authRepairStartedAt = 0;
    this.authRepairResultPath = "";
    this.authRepairDir = "";
    this.settingTab = null;
    this.organizing = false;
  }

  async onload() {
    await this.loadSettings();
    let settingsChanged = this.ensureBundledCleanerPaths();
    if (!this.settings.cliPath || !fs.existsSync(this.settings.cliPath)) {
      this.settings.cliPath = this.detectCli();
      settingsChanged = true;
    }
    if (settingsChanged) await this.saveSettings();

    this.addRibbonIcon("refresh-cw", "同步飞书妙记", () => this.runSync(true));
    this.addCommand({
      id: "feishu-minutes-sync-now",
      name: "立即同步飞书妙记",
      callback: () => this.runSync(true),
    });
    this.addCommand({
      id: "feishu-minutes-enrich-current",
      name: "补全当前妙记图文/待办/决策/金句",
      callback: () => this.enrichCurrentFile(),
    });
    this.addCommand({
      id: "feishu-minutes-enrich-all",
      name: "补全所有妙记笔记缺失模块（批量）",
      callback: () => this.enrichAllFiles(),
    });
    this.addCommand({
      id: "feishu-minutes-organize-existing",
      name: "按当前目录分类整理已有妙记",
      callback: () => this.organizeExistingNotes(true),
    });
    this.addCommand({
      id: "feishu-minutes-check-cli",
      name: "检查并修复 lark-cli 状态",
      callback: () => this.checkAndRepairCli(),
    });
    this.addCommand({
      id: "feishu-minutes-repair-background-auth",
      name: "修复 macOS 后台授权兼容性",
      callback: () => this.checkAndRepairCli(),
    });

    this.settingTab = new FeishuMinutesSettingTab(this.app, this);
    this.addSettingTab(this.settingTab);
    this.scheduleAutoSync();
    const warningTimer = window.setTimeout(() => {
      this.warnAboutBackgroundAuthCompatibility().catch((err) => this.log("后台授权兼容性提醒失败", err));
    }, 1800);
    this.register(() => window.clearTimeout(warningTimer));
    this.log("插件已加载", { version: PLUGIN_VERSION, cliPath: this.settings.cliPath });
  }

  onunload() {
    this.stopAuthRepairMonitor(false);
  }

  async loadSettings() {
    this.settings = Object.assign({}, DEFAULT_SETTINGS, await this.loadData());
    if (!new Set(["none", "year", "month", "week"]).has(this.settings.folderGrouping)) {
      this.settings.folderGrouping = "none";
    }
    this.settings.syncedTokens = this.settings.syncedTokens || {};
  }

  getBundledCleanerPaths() {
    const adapter = this.app && this.app.vault && this.app.vault.adapter;
    let vaultBasePath = "";
    try {
      if (adapter && typeof adapter.getBasePath === "function") {
        vaultBasePath = adapter.getBasePath();
      } else if (adapter && adapter.basePath) {
        vaultBasePath = adapter.basePath;
      }
    } catch (_) {}
    if (!vaultBasePath) return { script: "", glossary: "" };
    const pluginRoot = path.join(
      vaultBasePath,
      ".obsidian",
      "plugins",
      (this.manifest && this.manifest.id) || "feishu-minutes-sync",
    );
    return {
      script: path.join(pluginRoot, "resources", "obsidian_gate.py"),
      glossary: path.join(pluginRoot, "resources", "Glossary｜飞书妙记术语校准表.md"),
    };
  }

  ensureBundledCleanerPaths() {
    const bundled = this.getBundledCleanerPaths();
    let changed = false;
    if ((!this.settings.minutesCleanerScript || !fs.existsSync(this.settings.minutesCleanerScript))
      && bundled.script && fs.existsSync(bundled.script)) {
      this.settings.minutesCleanerScript = bundled.script;
      changed = true;
    }
    if ((!this.settings.minutesCleanerGlossary || !fs.existsSync(this.settings.minutesCleanerGlossary))
      && bundled.glossary && fs.existsSync(bundled.glossary)) {
      this.settings.minutesCleanerGlossary = bundled.glossary;
      changed = true;
    }
    return changed;
  }

  async saveSettings() {
    await this.saveData(this.settings);
  }

  refreshSettingTab() {
    try {
      if (this.settingTab && this.settingTab.containerEl && this.settingTab.containerEl.isConnected) {
        this.settingTab.display();
      }
    } catch (_) {}
  }

  log(...args) {
    if (this.settings && this.settings.debug) {
      console.log("[飞书妙记同步]", ...args);
    }
  }

  detectCli() {
    const candidates = [];
    const viaShell = this.whichViaLoginShell("lark-cli");
    if (viaShell) candidates.push(viaShell);
    try {
      const nvmRoot = path.join(os.homedir(), ".nvm/versions/node");
      if (fs.existsSync(nvmRoot)) {
        for (const version of fs.readdirSync(nvmRoot)) {
          candidates.push(path.join(nvmRoot, version, "bin/lark-cli"));
        }
      }
    } catch (_) {}
    candidates.push(
      ...CLI_CANDIDATES,
      path.join(os.homedir(), ".local/bin/lark-cli"),
      path.join(os.homedir(), ".npm-global/bin/lark-cli"),
    );
    for (const candidate of candidates) {
      try {
        if (candidate && fs.existsSync(candidate)) return candidate;
      } catch (_) {}
    }
    return "";
  }

  async resolveAndSaveCliPath() {
    const configured = String(this.settings.cliPath || "").trim();
    if (configured.includes("/") && fs.existsSync(configured)) {
      return configured;
    }
    const detected = this.detectCli();
    if (detected) {
      this.settings.cliPath = detected;
      await this.saveSettings();
      return detected;
    }
    return configured && !configured.includes("/") ? configured : "";
  }

  getNodeDir() {
    if (this.nodeDir == null) this.nodeDir = this.detectNodeDir();
    return this.nodeDir;
  }

  detectNodeDir() {
    const viaShell = this.whichViaLoginShell("node");
    if (viaShell) return path.dirname(viaShell);
    try {
      const nvmRoot = path.join(os.homedir(), ".nvm/versions/node");
      if (fs.existsSync(nvmRoot)) {
        for (const version of fs.readdirSync(nvmRoot).sort().reverse()) {
          const nodePath = path.join(nvmRoot, version, "bin/node");
          if (fs.existsSync(nodePath)) return path.dirname(nodePath);
        }
      }
    } catch (_) {}
    for (const nodePath of [
      "/opt/homebrew/opt/node@22/bin/node",
      "/opt/homebrew/bin/node",
      "/usr/local/bin/node",
      "/usr/bin/node",
    ]) {
      try {
        if (fs.existsSync(nodePath)) return path.dirname(nodePath);
      } catch (_) {}
    }
    return "";
  }

  whichViaLoginShell(command) {
    try {
      const shell = process.env.SHELL || "/bin/zsh";
      const output = execSync(`${shell} -lic 'command -v ${command}' 2>/dev/null`, {
        encoding: "utf-8",
        timeout: 8000,
      });
      const lines = String(output).split("\n").map((line) => line.trim()).filter(Boolean);
      for (const line of lines.reverse()) {
        if (line.startsWith("/") && fs.existsSync(line)) return line;
      }
    } catch (_) {}
    return "";
  }

  scheduleAutoSync() {
    if (!this.settings.autoSync) return;
    const interval = Math.max(5, this.settings.pollIntervalMinutes) * 60 * 1000;
    this.registerInterval(window.setInterval(() => {
      this.runSync(false).catch((err) => this.log("自动同步出错", err));
    }, interval));
    this.log(`自动同步开启，每 ${this.settings.pollIntervalMinutes} 分钟`);
  }

  runCli(args, cwd, options = {}) {
    if (this.settings.cliPath && this.settings.cliPath.includes("/") && !fs.existsSync(this.settings.cliPath)) {
      const detected = this.detectCli();
      if (detected) {
        this.settings.cliPath = detected;
        this.saveSettings();
      }
    }

    return new Promise((resolve, reject) => {
      const cliDir = path.dirname(this.settings.cliPath || "");
      const nodeDir = this.getNodeDir();
      const pathParts = [cliDir, nodeDir, "/opt/homebrew/bin", NODE_22_BIN, "/usr/local/bin"].filter(Boolean);
      const env = Object.assign({}, process.env, {
        PATH: `${pathParts.join(":")}:${process.env.PATH || ""}`,
        LARK_CLI_NO_PROXY: "1",
      });
      execFile(this.settings.cliPath, args, {
        env,
        cwd,
        maxBuffer: 80 * 1024 * 1024,
        timeout: 240000,
      }, (err, stdout, stderr) => {
        const combined = `${stdout || ""}\n${stderr || ""}`;
        if (this.settings.debug) {
          console.log("[飞书妙记同步] cli", args.join(" "), "->", combined.slice(0, 1600));
        }
        const json = this.extractJson(combined);
        if (json) {
          if (json.ok === false && !options.allowErrorResponse) {
            reject(new Error(this.formatCliError(json)));
            return;
          }
          resolve(json);
          return;
        }
        if (err) {
          reject(new Error(`lark-cli 执行失败：${err.message}\n${combined.slice(0, 1200)}`));
          return;
        }
        reject(new Error("无法解析 lark-cli 输出（见控制台日志）"));
      });
    });
  }

  runMinutesCleaner(transcript, metadata, cwd) {
    return new Promise((resolve, reject) => {
      const scriptPath = String(this.settings.minutesCleanerScript || "").trim();
      const glossaryPath = String(this.settings.minutesCleanerGlossary || "").trim();
      if (!scriptPath || !fs.existsSync(scriptPath)) {
        reject(new Error(`Minutes Cleaner 脚本不存在，已阻止入库：${scriptPath || "未配置"}`));
        return;
      }
      if (!glossaryPath || !fs.existsSync(glossaryPath)) {
        reject(new Error(`Minutes Cleaner 术语表不存在，已阻止入库：${glossaryPath || "未配置"}`));
        return;
      }
      if (!String(transcript || "").trim()) {
        reject(new Error("逐字稿为空，Minutes Cleaner 已阻止入库"));
        return;
      }

      const inputPath = path.join(cwd, "minutes-cleaner-input.json");
      const outputPath = path.join(cwd, "minutes-cleaner-output.json");
      fs.writeFileSync(inputPath, JSON.stringify({
        minute_token: metadata.minuteToken || "",
        title: metadata.title || "",
        create_time: metadata.createTime || "",
        transcript,
      }), { encoding: "utf8", mode: 0o600 });

      const pythonPath = fs.existsSync("/usr/bin/python3") ? "/usr/bin/python3" : "python3";
      execFile(pythonPath, [
        scriptPath,
        "--input", inputPath,
        "--output", outputPath,
        "--glossary", glossaryPath,
      ], {
        cwd,
        maxBuffer: 80 * 1024 * 1024,
        timeout: 120000,
      }, (err, stdout, stderr) => {
        if (err) {
          const detail = String(stderr || stdout || err.message || err).trim().slice(0, 1200);
          reject(new Error(`Minutes Cleaner 清洗失败，已阻止入库：${detail}`));
          return;
        }
        try {
          const report = JSON.parse(fs.readFileSync(outputPath, "utf8"));
          if (report.status !== "passed" || !String(report.cleaned_transcript || "").trim()) {
            throw new Error("清洗报告未通过或结果为空");
          }
          if (!report.speaker_headers_preserved || Number(report.segment_count || 0) < 1) {
            throw new Error("说话人或时间戳结构校验未通过");
          }
          resolve(report);
        } catch (parseError) {
          reject(new Error(`Minutes Cleaner 结果校验失败，已阻止入库：${parseError.message || parseError}`));
        }
      });
    });
  }

  extractJson(text) {
    const start = text.indexOf("{");
    const end = text.lastIndexOf("}");
    if (start < 0 || end <= start) return null;
    try {
      return JSON.parse(text.slice(start, end + 1));
    } catch (_) {
      return null;
    }
  }

  formatCliError(payload) {
    const error = payload && payload.error;
    const message = typeof error === "string"
      ? error
      : error && (error.message || error.type || error.subtype);
    const missing = payload && payload.missing;
    const missingText = Array.isArray(missing) && missing.length ? `；缺少权限：${missing.join("、")}` : "";
    return `lark-cli 返回失败：${message || "未知错误"}${missingText}`;
  }

  getBackgroundAuthCompatibility() {
    if (process.platform !== "darwin") {
      return {
        applicable: false,
        ok: true,
        fileBacked: false,
        securePermissions: true,
        hasCredentialFiles: false,
      };
    }

    const credentialDir = path.join(os.homedir(), "Library", "Application Support", "lark-cli");
    const masterKeyFile = path.join(credentialDir, "master.key.file");
    let credentialFiles = [];
    try {
      credentialFiles = fs.readdirSync(credentialDir)
        .filter((name) => /^cli_[^/]+_ou_[^/]+\.enc$/i.test(name));
    } catch (_) {}

    let fileBacked = false;
    let readable = false;
    let securePermissions = false;
    let mode;
    try {
      const stat = fs.statSync(masterKeyFile);
      fileBacked = stat.isFile();
      mode = stat.mode & 0o777;
      securePermissions = (mode & 0o077) === 0;
      fs.accessSync(masterKeyFile, fs.constants.R_OK);
      readable = true;
    } catch (_) {}

    return {
      applicable: true,
      ok: fileBacked && readable && securePermissions,
      fileBacked,
      readable,
      securePermissions,
      mode,
      masterKeyFile,
      credentialDir,
      credentialCount: credentialFiles.length,
      hasCredentialFiles: credentialFiles.length > 0,
    };
  }

  readFileTail(filePath, maxBytes = 128 * 1024) {
    let fd;
    try {
      const stat = fs.statSync(filePath);
      const length = Math.min(stat.size, maxBytes);
      const start = Math.max(0, stat.size - length);
      const buffer = Buffer.alloc(length);
      fd = fs.openSync(filePath, "r");
      fs.readSync(fd, buffer, 0, length, start);
      return buffer.toString("utf8");
    } catch (_) {
      return "";
    } finally {
      if (fd != null) {
        try { fs.closeSync(fd); } catch (_) {}
      }
    }
  }

  findRecentCredentialStorageError() {
    if (process.platform !== "darwin") return null;
    const logDir = path.join(os.homedir(), ".lark-cli", "logs");
    let files = [];
    try {
      files = fs.readdirSync(logDir)
        .filter((name) => /^auth-\d{4}-\d{2}-\d{2}\.log$/.test(name))
        .sort()
        .reverse()
        .slice(0, 5);
    } catch (_) {
      return null;
    }

    for (const name of files) {
      const logPath = path.join(logDir, name);
      try {
        if (Date.now() - fs.statSync(logPath).mtimeMs > 24 * 60 * 60 * 1000) continue;
      } catch (_) {
        continue;
      }
      const lines = this.readFileTail(logPath).split("\n").reverse();
      for (const line of lines) {
        if (!line.includes("auth-error:") || !line.includes("component=keychain")) continue;
        if (/keychain access blocked/i.test(line)) {
          return { code: "KEYCHAIN_ACCESS_BLOCKED", source: name };
        }
        if (/decrypt|malformed|corrupt/i.test(line)) {
          return { code: "CREDENTIAL_DECRYPTION_FAILED", source: name };
        }
        if (/keychain unavailable|access denied|permission denied/i.test(line)) {
          return { code: "KEYCHAIN_UNAVAILABLE", source: name };
        }
      }
    }
    return null;
  }

  async getAuthorizationHealth() {
    const status = await this.runCli(["auth", "status", "--verify", "--json"]);
    const user = status && status.identities && status.identities.user;
    const compatibility = this.getBackgroundAuthCompatibility();
    if (!user || user.status !== "ready" || user.verified === false) {
      const storageError = this.findRecentCredentialStorageError();
      if (storageError && compatibility.applicable && !compatibility.fileBacked) {
        return {
          ok: false,
          code: storageError.code,
          reason: "macOS 已阻止 Obsidian 或后台任务读取 lark-cli 解密主密钥；本地飞书授权可能仍然存在",
          missing: [],
          repairable: !compatibility.ok,
          compatibility,
          user,
        };
      }
      if (user && user.status === "missing"
        && compatibility.applicable
        && compatibility.hasCredentialFiles
        && !compatibility.fileBacked) {
        return {
          ok: false,
          code: "BACKGROUND_AUTH_NOT_CONFIGURED",
          reason: "检测到本地加密授权文件，但 macOS 后台兼容模式尚未启用；CLI 可能把钥匙串访问失败误报成授权缺失",
          missing: [],
          repairable: true,
          compatibility,
          user,
        };
      }
      return {
        ok: false,
        reason: user && (user.message || user.hint) || "没有可用的飞书用户授权",
        missing: REQUIRED_USER_SCOPES.slice(),
        repairable: false,
        compatibility,
        user,
      };
    }
    const granted = new Set(String(user.scope || "").split(/\s+/).filter(Boolean));
    const missing = REQUIRED_USER_SCOPES.filter((scope) => !granted.has(scope));
    if (missing.length) {
      return {
        ok: false,
        reason: "当前 token 缺少同步正文所需权限",
        missing,
        user,
        repairable: false,
        compatibility,
      };
    }
    return { ok: true, user, missing: [], compatibility };
  }

  async checkCli() {
    try {
      const cliPath = await this.resolveAndSaveCliPath();
      if (!cliPath) {
        new Notice("未找到 lark-cli。请先安装 lark-cli，再点击“检查并修复”。", 15000);
        return { ok: false, code: "CLI_NOT_FOUND" };
      }
      const health = await this.getAuthorizationHealth();
      if (health.ok) {
        const refreshUntil = health.user.refreshExpiresAt
          ? `；滚动刷新有效期至 ${new Date(health.user.refreshExpiresAt).toLocaleString()}`
          : "";
        const backgroundWarning = health.compatibility
          && health.compatibility.applicable
          && !health.compatibility.ok
          ? "\n当前授权可用，但 macOS 后台兼容模式未配置，后续可能再次被钥匙串拦截。请在设置中点击“检查并修复”。"
          : "";
        new Notice(`lark-cli 已就绪：${health.user.userName || ""}，滚动刷新与妙记正文权限齐全${refreshUntil}${backgroundWarning}`, 15000);
      } else {
        const missingText = health.missing.length ? `\n缺少：${health.missing.join("\n")}` : "";
        const repairText = "\n点击插件设置中的“检查并修复”，插件会自动选择存储修复或完整授权流程。";
        new Notice(`飞书授权不可用：${health.reason}${missingText}${repairText}\n同步已安全阻断，不会创建空文件。`, 18000);
      }
      return health;
    } catch (err) {
      new Notice(`lark-cli 不可用：${err.message}`);
      return { ok: false, code: "CLI_ERROR", error: err };
    }
  }

  async checkAndRepairCli() {
    if (this.authRepairMonitorId != null) {
      new Notice("飞书授权修复正在进行。请在已打开的终端或飞书页面完成本人授权，插件会自动复检。", 12000);
      return { ok: false, action: "repair_in_progress" };
    }

    const cliPath = await this.resolveAndSaveCliPath();
    if (!cliPath) {
      new Notice("没有检测到 lark-cli，暂时无法自动修复。请先安装 Node 22 和 lark-cli，再点击“检查并修复”。", 18000);
      return { ok: false, code: "CLI_NOT_FOUND" };
    }

    let health;
    try {
      health = await this.getAuthorizationHealth();
    } catch (err) {
      new Notice(`lark-cli 检查失败：${err.message}`, 18000);
      return { ok: false, code: "CLI_ERROR", error: err };
    }

    const compatibilityReady = !health.compatibility
      || !health.compatibility.applicable
      || health.compatibility.ok;
    if (health.ok && compatibilityReady) {
      const refreshUntil = health.user.refreshExpiresAt
        ? `；滚动刷新有效期至 ${new Date(health.user.refreshExpiresAt).toLocaleString()}`
        : "";
      new Notice(`检查通过：${health.user.userName || "飞书用户"}，8 项权限与后台授权均已就绪${refreshUntil}`, 15000);
      return { ok: true, action: "ready", health };
    }

    if (process.platform !== "darwin") {
      const missingText = health.missing && health.missing.length
        ? `缺少：${health.missing.join("、")}`
        : health.reason;
      new Notice(`当前系统无法使用 macOS 终端自修复流程。${missingText || "请重新完成飞书用户授权。"}`, 18000);
      return { ok: false, code: health.code || "AUTH_REQUIRED", health };
    }

    const repair = this.openSelfRepairTerminal();
    if (!repair) return { ok: false, code: "REPAIR_LAUNCH_FAILED", health };
    this.startAuthRepairMonitor(repair.resultPath, repair.repairDir);

    const needsUserAuthorization = !health.ok && !health.repairable;
    const actionText = needsUserAuthorization
      ? "已开始修复；终端会自动发起完整 8 项权限授权。飞书页面出现时，请完成本人确认。"
      : "已开始修复 macOS 后台授权；插件会自动复检，无需再次点击。";
    new Notice(actionText, 18000);
    return { ok: false, action: "repair_launched", health };
  }

  async warnAboutBackgroundAuthCompatibility() {
    const compatibility = this.getBackgroundAuthCompatibility();
    if (!compatibility.applicable || compatibility.ok || !compatibility.hasCredentialFiles) return;
    const now = Date.now();
    const last = Number(this.settings.lastBackgroundAuthWarningAt || 0);
    if (now - last < 24 * 60 * 60 * 1000) return;
    this.settings.lastBackgroundAuthWarningAt = now;
    await this.saveSettings();
    const message = compatibility.fileBacked && !compatibility.securePermissions
      ? "飞书妙记同步检测到后台授权文件权限过宽。请到插件设置点击“检查并修复”。"
      : "飞书妙记同步检测到 macOS 后台授权兼容模式尚未启用。请到插件设置点击“检查并修复”，插件会自动处理并复检。";
    new Notice(message, 18000);
  }

  repairBackgroundAuth() {
    return this.checkAndRepairCli();
  }

  shellQuote(value) {
    return `'${String(value).replace(/'/g, `'\\''`)}'`;
  }

  buildSelfRepairScript({ cliPath, nodePath, repairDir, resultPath, statusPath }) {
    const cli = this.shellQuote(cliPath);
    const node = this.shellQuote(nodePath);
    const masterKey = this.shellQuote(path.join(
      os.homedir(),
      "Library",
      "Application Support",
      "lark-cli",
      "master.key.file",
    ));
    const statusFile = this.shellQuote(statusPath);
    const resultFile = this.shellQuote(resultPath);
    const scriptFile = this.shellQuote(path.join(repairDir, "修复飞书妙记授权.command"));
    const requiredScopesJson = JSON.stringify(REQUIRED_USER_SCOPES);
    const scopes = this.shellQuote(REQUIRED_USER_SCOPES.join(" "));
    return `#!/bin/zsh
set +e
clear
echo '飞书妙记同步：自动检查并修复'
echo '将修复 macOS 后台授权；仅在确有缺失时发起飞书本人授权。'
echo '过程不会显示或上传 access token。'
echo
CLI_PATH=${cli}
NODE_PATH=${node}
MASTER_KEY_FILE=${masterKey}
STATUS_FILE=${statusFile}
RESULT_FILE=${resultFile}
SCOPES=${scopes}

ensure_background_auth() {
  if [ -f "$MASTER_KEY_FILE" ]; then
    /bin/chmod 600 "$MASTER_KEY_FILE"
    return $?
  fi
  "$CLI_PATH" config keychain-downgrade
}

verify_auth() {
  /bin/rm -f -- "$STATUS_FILE"
  LARK_CLI_NO_PROXY=1 LARKSUITE_CLI_NO_UPDATE_NOTIFIER=1 LARKSUITE_CLI_NO_SKILLS_NOTIFIER=1 \
    "$CLI_PATH" auth status --verify --json > "$STATUS_FILE"
  cli_result=$?
  if [ "$cli_result" -ne 0 ]; then
    return "$cli_result"
  fi
  "$NODE_PATH" - "$STATUS_FILE" <<'NODE'
const fs = require("fs");
const status = JSON.parse(fs.readFileSync(process.argv[2], "utf8"));
const user = status && status.identities && status.identities.user || {};
const required = ${requiredScopesJson};
const granted = new Set(String(user.scope || "").split(/\\s+/).filter(Boolean));
const missing = required.filter((scope) => !granted.has(scope));
if (user.status !== "ready" || user.verified === false) {
  console.error("用户授权不可用，将发起本人授权。");
  process.exit(2);
}
if (missing.length) {
  console.error("授权缺少：" + missing.join(", "));
  process.exit(3);
}
console.log("验证通过：用户身份、offline_access 与 7 项正文权限齐全。");
NODE
}

echo '1/3 修复并验证后台授权存储...'
ensure_background_auth
verify_auth
result=$?

if [ "$result" -ne 0 ]; then
  echo
  echo '2/3 当前授权不完整，正在打开飞书本人授权页面...'
  "$CLI_PATH" auth login --scope "$SCOPES"
  result=$?
  if [ "$result" -eq 0 ]; then
    echo
    echo '3/3 固化后台授权并复检 8 项权限...'
    ensure_background_auth
    result=$?
    if [ "$result" -eq 0 ]; then
      verify_auth
      result=$?
    fi
  fi
fi

/bin/rm -f -- "$STATUS_FILE"
echo
if [ "$result" -eq 0 ] && [ -r "$MASTER_KEY_FILE" ]; then
  /bin/chmod 600 "$MASTER_KEY_FILE"
  printf 'success\\n' > "$RESULT_FILE"
  echo '修复完成：Obsidian 将自动复检并恢复同步。'
  sleep 4
else
  printf 'failed:%s\\n' "$result" > "$RESULT_FILE"
  echo '修复未完成。请保留本窗口中的错误信息并联系维护者。'
  echo
  read -k 1 -s '?按任意键关闭此窗口...'
fi
/bin/rm -f -- ${scriptFile}
exit "$result"
`;
  }

  openSelfRepairTerminal() {
    const cliPath = this.settings.cliPath || this.detectCli();
    if (!cliPath || !cliPath.includes("/") || !fs.existsSync(cliPath)) {
      new Notice("找不到 lark-cli。请先安装 lark-cli，或在插件设置中填写正确路径。", 15000);
      return null;
    }

    let repairDir;
    try {
      repairDir = fs.mkdtempSync(path.join(os.tmpdir(), "feishu-minutes-sync-repair-"));
      fs.chmodSync(repairDir, 0o700);
      const scriptPath = path.join(repairDir, "修复飞书妙记授权.command");
      const statusFile = path.join(repairDir, "auth-status.json");
      const resultPath = path.join(repairDir, "result.txt");
      const nodePath = path.join(this.getNodeDir(), "node");
      const script = this.buildSelfRepairScript({
        cliPath,
        nodePath: fs.existsSync(nodePath) ? nodePath : "node",
        repairDir,
        resultPath,
        statusPath: statusFile,
      });
      fs.writeFileSync(scriptPath, script, { mode: 0o700 });
      execFile("/usr/bin/open", [scriptPath], (err) => {
        if (err) {
          this.stopAuthRepairMonitor(true);
          new Notice(`无法打开终端修复：${err.message}`, 15000);
        }
      });
      return { repairDir, resultPath, scriptPath };
    } catch (err) {
      if (repairDir) {
        try { fs.rmSync(repairDir, { recursive: true, force: true }); } catch (_) {}
      }
      new Notice(`准备终端修复失败：${err.message}`, 15000);
      return null;
    }
  }

  startAuthRepairMonitor(resultPath, repairDir) {
    this.stopAuthRepairMonitor(false);
    this.authRepairStartedAt = Date.now();
    this.authRepairResultPath = resultPath;
    this.authRepairDir = repairDir;
    let checking = false;
    const poll = async () => {
      if (checking) return;
      checking = true;
      try {
        let result = "";
        try { result = fs.readFileSync(resultPath, "utf8").trim(); } catch (_) {}
        if (result === "success") {
          const cliPath = await this.resolveAndSaveCliPath();
          const health = cliPath ? await this.getAuthorizationHealth() : null;
          const compatible = health && (!health.compatibility
            || !health.compatibility.applicable
            || health.compatibility.ok);
          if (health && health.ok && compatible) {
            const userName = health.user && health.user.userName || "飞书用户";
            this.stopAuthRepairMonitor(true);
            this.refreshSettingTab();
            new Notice(`修复成功：${userName} 的 8 项权限与后台授权均已就绪，自动同步已恢复。`, 18000);
            return;
          }
          this.stopAuthRepairMonitor(true);
          this.refreshSettingTab();
          new Notice("终端修复已执行，但 Obsidian 复检仍未通过。请再次点击“检查并修复”查看最新原因。", 18000);
          return;
        }
        if (result.startsWith("failed:")) {
          this.stopAuthRepairMonitor(true);
          this.refreshSettingTab();
          new Notice("自动修复未完成。终端窗口保留了具体错误；处理后可再次点击“检查并修复”。", 18000);
          return;
        }
        if (Date.now() - this.authRepairStartedAt > 10 * 60 * 1000) {
          this.stopAuthRepairMonitor(false);
          this.refreshSettingTab();
          new Notice("等待飞书本人授权已超过 10 分钟。完成授权后，请再次点击“检查并修复”。", 18000);
        }
      } catch (err) {
        this.log("自动修复复检失败", err);
      } finally {
        checking = false;
      }
    };
    this.authRepairMonitorId = window.setInterval(poll, 1500);
    poll();
  }

  stopAuthRepairMonitor(cleanup) {
    if (this.authRepairMonitorId != null) {
      window.clearInterval(this.authRepairMonitorId);
      this.authRepairMonitorId = null;
    }
    const repairDir = this.authRepairDir;
    this.authRepairStartedAt = 0;
    this.authRepairResultPath = "";
    this.authRepairDir = "";
    const safePrefix = path.join(os.tmpdir(), "feishu-minutes-sync-repair-");
    if (cleanup && repairDir && repairDir.startsWith(safePrefix)) {
      try { fs.rmSync(repairDir, { recursive: true, force: true }); } catch (_) {}
    }
  }

  async searchMinutes(startDate, endDate, participantFlag) {
    const result = [];
    let pageToken;
    for (let page = 0; page < 50; page += 1) {
      const args = [
        "minutes", "+search",
        "--as", "user",
        participantFlag || "--owner-ids", "me",
        "--start", startDate,
        "--end", endDate,
        "--format", "json",
        "--page-size", "30",
      ];
      if (pageToken) args.push("--page-token", pageToken);
      const response = await this.runCli(args);
      if (!response || !response.ok) {
        this.log("search 非 ok", response);
        break;
      }
      const data = response.data || {};
      for (const item of data.items || []) {
        if (!item || !item.token) continue;
        result.push({
          token: item.token,
          title: (item.display_info || "").split("\n")[0] || "(无标题妙记)",
          url: item.meta_data && item.meta_data.app_link || "",
          startMs: this.parseStartMs(item),
        });
      }
      if (data.has_more && data.page_token) pageToken = data.page_token;
      else break;
    }
    return result;
  }

  async searchRange(startMs, endMs) {
    const seen = new Set();
    const all = [];
    let cursor = endMs;
    let guard = 0;
    while (cursor >= startMs && guard++ < 120) {
      const chunkStart = Math.max(startMs, cursor - 29 * 86400000);
      const owner = await this.searchMinutes(this.fmtDate(chunkStart), this.fmtDate(cursor), "--owner-ids");
      const participant = await this.searchMinutes(this.fmtDate(chunkStart), this.fmtDate(cursor), "--participant-ids");
      for (const minute of [...owner, ...participant]) {
        if (!seen.has(minute.token)) {
          seen.add(minute.token);
          all.push(minute);
        }
      }
      cursor = chunkStart - 86400000;
    }
    return all;
  }

  async fetchNotes(minuteToken) {
    const tmpDir = path.join(os.tmpdir(), `obsidian-feishu-minutes-${minuteToken}-${Date.now()}`);
    fs.mkdirSync(tmpDir, { recursive: true });

    let transcript = "";
    let summary = "";
    let notReady = false;
    let noteDocToken = "";
    let verbatimDocToken = "";
    let artifacts = {};
    let smartDocMarkdown = "";
    let smartDocXml = "";
    let title = "";
    let createTime = "";
    let cleaning = null;

    const response = await this.runCli([
      "vc", "+notes",
      "--as", "user",
      "--minute-tokens", minuteToken,
      "--overwrite",
      "--format", "json",
      "--output-dir", ".",
    ], tmpDir);
    const note = response && response.data && response.data.notes && response.data.notes[0];
    if (!note) throw new Error(`妙记 ${minuteToken} 未返回正文数据，本次不创建文件`);
    if (note.error) {
      const noteError = this.extractText(note.error);
      if (noteError.toLowerCase().includes("not ready")) {
        notReady = true;
        return { transcript, summary, artifacts, notReady };
      }
      this.log("note error", note.error);
      throw new Error(`妙记 ${minuteToken} 正文读取失败：${noteError}`);
    }

    title = note.title || "";
    createTime = note.create_time || "";
    noteDocToken = note.note_doc_token || "";
    verbatimDocToken = note.verbatim_doc_token || "";
    artifacts = note.artifacts || {};
    if (this.settings.includeSummary) summary = this.extractText(artifacts.summary);
    if (this.settings.includeTranscript) {
      if (typeof artifacts.transcript === "string" && artifacts.transcript.trim()) {
        transcript = artifacts.transcript;
      } else if (artifacts.transcript_file) {
        let transcriptFile = artifacts.transcript_file;
        if (!path.isAbsolute(transcriptFile)) transcriptFile = path.resolve(tmpDir, transcriptFile);
        try {
          transcript = fs.readFileSync(transcriptFile, "utf-8");
        } catch (err) {
          this.log("读逐字稿文件失败", transcriptFile, err);
        }
      }
    }

    cleaning = await this.runMinutesCleaner(transcript, {
      minuteToken,
      title,
      createTime,
    }, tmpDir);
    transcript = cleaning.cleaned_transcript;

    if (this.settings.includeSmartDoc && noteDocToken) {
      try {
        const markdownResponse = await this.runCli([
          "docs", "+fetch",
          "--as", "user",
          "--api-version", "v2",
          "--doc", noteDocToken,
          "--doc-format", "markdown",
          "--detail", "simple",
          "--format", "json",
        ], tmpDir);
        smartDocMarkdown = markdownResponse && markdownResponse.data && markdownResponse.data.document && markdownResponse.data.document.content || "";
      } catch (err) {
        this.log("读取智能纪要 Markdown 失败", noteDocToken, err);
        throw new Error(`智能纪要正文读取失败，本次不写入：${err.message || err}`);
      }

      if (this.settings.includeImages || this.settings.includeWhiteboards) {
        try {
          const xmlResponse = await this.runCli([
            "docs", "+fetch",
            "--as", "user",
            "--api-version", "v2",
            "--doc", noteDocToken,
            "--doc-format", "xml",
            "--detail", "full",
            "--format", "json",
          ], tmpDir);
          smartDocXml = xmlResponse && xmlResponse.data && xmlResponse.data.document && xmlResponse.data.document.content || "";
        } catch (err) {
          this.log("读取智能纪要 XML 失败", noteDocToken, err);
        }
      }
    }

    if (smartDocMarkdown && (this.settings.includeImages || this.settings.includeWhiteboards)) {
      smartDocMarkdown = await this.localizeSmartDocMedia(smartDocMarkdown, smartDocXml, minuteToken, title || minuteToken, tmpDir);
    }
    if (smartDocMarkdown) smartDocMarkdown = this.normalizeSmartMarkdown(smartDocMarkdown);
    if (smartDocMarkdown) smartDocMarkdown = this.filterSmartSections(smartDocMarkdown);

    const notes = {
      transcript,
      summary,
      artifacts,
      notReady,
      noteDocToken,
      verbatimDocToken,
      smartDocMarkdown,
      title,
      createTime,
      cleaning,
    };
    if (!this.hasSubstantiveNotes(notes)) {
      throw new Error(`妙记 ${minuteToken} 没有返回逐字稿、总结或智能纪要正文，本次不创建链接占位文件`);
    }
    return notes;
  }

  hasSubstantiveNotes(notes) {
    if (!notes) return false;
    if (String(notes.smartDocMarkdown || "").trim()) return true;
    if (String(notes.summary || "").trim()) return true;
    if (String(notes.transcript || "").trim()) return true;
    const artifacts = notes.artifacts || {};
    const todos = artifacts.todos || artifacts.minute_todos || [];
    const chapters = artifacts.chapters || artifacts.minute_chapters || [];
    return todos.some((item) => this.extractText(item).trim())
      || chapters.some((item) => this.extractText(item).trim());
  }

  extractText(value) {
    if (value == null) return "";
    if (typeof value === "string") return value;
    if (Array.isArray(value)) return value.map((item) => this.extractText(item)).filter(Boolean).join("\n");
    if (typeof value === "object") {
      for (const key of ["content", "text", "summary", "summary_content", "title", "md", "value"]) {
        if (typeof value[key] === "string" && value[key].trim()) return value[key];
      }
      try { return JSON.stringify(value, null, 2); } catch (_) { return String(value); }
    }
    return String(value);
  }

  async runSync(manual) {
    if (this.syncing) {
      if (manual) new Notice("正在同步中…");
      return;
    }
    this.syncing = true;
    if (manual) new Notice("开始同步飞书妙记…");
    try {
      const auth = await this.getAuthorizationHealth();
      if (!auth.ok) {
        const missingText = auth.missing.length ? `；缺少：${auth.missing.join("、")}` : "";
        const error = new Error(`飞书授权检查未通过：${auth.reason}${missingText}。本次未创建或更新任何文件`);
        error.code = "AUTH_UNAVAILABLE";
        throw error;
      }
      const end = Date.now();
      const start = end - this.settings.lookbackDays * 86400000;
      const minutes = await this.searchRange(start, end);
      const queue = [];
      for (const minute of minutes) {
        if (!this.settings.syncedTokens[minute.token]) {
          queue.push(minute);
          continue;
        }
        if (this.settings.updateExisting) {
          const existing = await this.findExistingMinuteFile(minute.token);
          if (!existing || !(await this.isFileContentComplete(existing))) queue.push(minute);
        }
      }

      this.log(`搜到 ${minutes.length} 条，待处理 ${queue.length} 条`);
      if (queue.length === 0) {
        if (manual) new Notice("没有新的妙记需要同步");
        return;
      }
      await this.ensureFolder(this.settings.syncFolder);
      if (manual && queue.length > 3) new Notice(`找到 ${queue.length} 条待处理妙记，逐条同步中…`);

      let created = 0;
      let updated = 0;
      let pending = 0;
      let failed = 0;
      for (const minute of queue) {
        try {
          const notes = await this.fetchNotes(minute.token);
          if (notes.notReady) {
            pending += 1;
            continue;
          }
          const result = await this.writeMinuteNote(minute, notes);
          if (result === "created") created += 1;
          if (result === "updated") updated += 1;
          this.settings.syncedTokens[minute.token] = new Date().toISOString();
        } catch (err) {
          this.log("处理妙记失败", minute.token, err);
          failed += 1;
        }
      }
      await this.saveSettings();
      const now = Date.now();
      const backgroundIssueDue = (pending || failed) && now - this.lastBackgroundErrorNoticeAt >= 6 * 60 * 60 * 1000;
      if (manual || created || updated || backgroundIssueDue) {
        new Notice(`同步完成：新增 ${created} 条，补全 ${updated} 条${pending ? `，${pending} 条还在生成中（稍后自动重试）` : ""}${failed ? `，失败 ${failed} 条（未写入，稍后重试）` : ""}`);
        if (!manual && (pending || failed)) this.lastBackgroundErrorNoticeAt = now;
      }
    } catch (err) {
      this.log("runSync 异常", err);
      const now = Date.now();
      const shouldNotice = manual || err.code !== "AUTH_UNAVAILABLE" || now - this.lastBackgroundErrorNoticeAt >= 6 * 60 * 60 * 1000;
      if (shouldNotice) {
        new Notice(`同步出错：${err.message || err}`, 15000);
        if (!manual) this.lastBackgroundErrorNoticeAt = now;
      }
    } finally {
      this.syncing = false;
    }
  }

  async enrichCurrentFile() {
    const file = this.app.workspace.getActiveFile();
    if (!file || file.extension !== "md") {
      new Notice("请先打开一条 FeishuMinutes 妙记笔记");
      return;
    }
    const cache = this.app.metadataCache.getFileCache(file);
    let minuteToken = cache && cache.frontmatter && cache.frontmatter.minute_token;
    if (!minuteToken) {
      const text = await this.app.vault.read(file);
      const match = text.match(/minute_token:\s*(\S+)/) || text.match(/minutes\/([a-z0-9]+)/);
      minuteToken = match && match[1];
    }
    if (!minuteToken) {
      new Notice("当前笔记没有 minute_token，无法补全");
      return;
    }

    new Notice("开始补全当前妙记的图文/待办/决策/金句…");
    try {
      const notes = await this.fetchNotes(minuteToken);
      if (notes.notReady || !this.hasSubstantiveNotes(notes)) {
        throw new Error(`妙记 ${minuteToken} 正文尚未生成或读取为空，当前笔记未修改`);
      }
      const original = await this.app.vault.read(file);
      if (this.settings.backupBeforeEnrich) {
        const backupPath = await this.uniquePath(`${file.path}.bak-${this.timestamp()}`);
        await this.app.vault.create(backupPath, original);
      }
      const frontmatter = cache && cache.frontmatter || {};
      const minute = {
        token: minuteToken,
        title: frontmatter.title || notes.title || file.basename.replace(/^\d{4}-\d{2}-\d{2}\s+/, ""),
        url: frontmatter.source || `https://beike.feishu.cn/minutes/${minuteToken}`,
        startMs: frontmatter.date ? new Date(`${frontmatter.date}T00:00:00`).getTime() : Date.now(),
      };
      const content = this.buildMinuteMarkdown(minute, notes);
      await this.app.vault.modify(file, content);
      this.settings.syncedTokens[minuteToken] = new Date().toISOString();
      await this.saveSettings();
      new Notice("当前妙记已补全：图文、待办、关键决策、其他决策、金句时刻已同步");
    } catch (err) {
      this.log("补全当前妙记失败", err);
      new Notice(`补全失败：${err.message || err}`);
    }
  }

  // 批量补全：遍历妙记文件夹，把所有已迁移笔记补齐缺失的图文/画板/各模块。
  // 跳过：已是当前版本的、练习录音、无智能纪要(notReady)。每条带备份、错误隔离、进度提示。
  async enrichAllFiles() {
    const folder = normalizePath(this.settings.syncFolder);
    const abstract = this.app.vault.getAbstractFileByPath(folder);
    if (!abstract || !abstract.children) {
      new Notice(`找不到妙记文件夹：${folder}`);
      return;
    }
    const tasks = [];
    const seen = new Set();
    for (const child of this.getMarkdownFilesRecursively(abstract)) {
      if (/^README|^_插件|^_/.test(child.basename)) continue;
      if (/soundcore|新录音/i.test(child.basename)) continue; // 跳过练习录音
      const cache = this.app.metadataCache.getFileCache(child);
      const fm = (cache && cache.frontmatter) || {};
      let token = fm.minute_token;
      if (!token) {
        const text = await this.app.vault.cachedRead(child);
        const m = text.match(/minute_token:\s*(\S+)/);
        token = m && m[1];
      }
      if (!token || token === "飞书妙记唯一" || seen.has(token)) continue;
      // 当前版本且正文完整才跳过；同版本的链接占位文件必须允许重试。
      if (fm.sync_version === PLUGIN_VERSION && await this.isFileContentComplete(child)) continue;
      seen.add(token);
      tasks.push({ file: child, token });
    }
    if (!tasks.length) {
      new Notice("没有需要补全的妙记笔记（其余均已是最新版本）");
      return;
    }
    new Notice(`开始补全 ${tasks.length} 条妙记笔记（含图文/画板/各模块），请稍候…`);
    let ok = 0, skip = 0, fail = 0;
    for (let i = 0; i < tasks.length; i++) {
      const { file, token } = tasks[i];
      try {
        const notes = await this.fetchNotes(token);
        if (notes.notReady) { skip += 1; continue; }
        const original = await this.app.vault.read(file);
        if (this.settings.backupBeforeEnrich) {
          const backupPath = await this.uniquePath(`${file.path}.bak-${this.timestamp()}`);
          await this.app.vault.create(backupPath, original);
        }
        const cache = this.app.metadataCache.getFileCache(file);
        const fm = (cache && cache.frontmatter) || {};
        const minute = {
          token,
          title: fm.title || notes.title || file.basename.replace(/^\d{4}-\d{2}-\d{2}\s+/, ""),
          url: fm.source || `https://beike.feishu.cn/minutes/${token}`,
          startMs: fm.date ? new Date(`${fm.date}T00:00:00`).getTime() : Date.now(),
        };
        await this.app.vault.modify(file, this.buildMinuteMarkdown(minute, notes));
        this.settings.syncedTokens[token] = new Date().toISOString();
        ok += 1;
        if ((i + 1) % 5 === 0 || i === tasks.length - 1) {
          new Notice(`补全进度 ${i + 1}/${tasks.length}…`);
        }
      } catch (err) {
        this.log("批量补全失败", token, err);
        fail += 1;
      }
    }
    await this.saveSettings();
    new Notice(`批量补全完成：成功 ${ok}，跳过 ${skip}（无智能纪要/未生成），失败 ${fail}`);
  }

  async writeMinuteNote(minute, notes) {
    if (!this.hasSubstantiveNotes(notes)) {
      throw new Error(`妙记 ${minute.token} 正文为空，已阻止写入`);
    }
    const existing = await this.findExistingMinuteFile(minute.token);
    const content = this.buildMinuteMarkdown(minute, notes);
    if (existing) {
      if (!this.settings.updateExisting) {
        this.settings.syncedTokens[minute.token] = new Date().toISOString();
        this.log("已存在相同 minute_token 笔记，跳过", existing.path);
        return "skipped";
      }
      await this.app.vault.modify(existing, content);
      this.log("已补全", existing.path);
      return "updated";
    }

    const date = this.fmtDate(minute.startMs || Date.now());
    const title = this.sanitize(minute.title || notes.title || "未命名妙记");
    const folder = this.getMeetingFolder(minute.startMs || Date.now());
    let notePath = normalizePath(`${folder}/${date} ${title}.md`);
    if (this.app.vault.getAbstractFileByPath(notePath)) {
      notePath = normalizePath(`${folder}/${date} ${title} ${minute.token.slice(-6)}.md`);
    }
    await this.ensureFolder(folder);
    await this.app.vault.create(notePath, content);
    this.log("已写入", notePath);
    return "created";
  }

  buildMinuteMarkdown(minute, notes) {
    if (!notes.cleaning || notes.cleaning.status !== "passed") {
      throw new Error(`妙记 ${minute.token} 未通过 Minutes Cleaner，已阻止入库`);
    }
    const date = this.fmtDate(minute.startMs || Date.now());
    const title = (minute.title || notes.title || "未命名妙记").replace(/\n/g, " ");
    const source = minute.url || `https://beike.feishu.cn/minutes/${minute.token}`;
    const lines = [];

    lines.push("---");
    lines.push("type: feishu-minute");
    lines.push(`minute_token: ${minute.token}`);
    if (notes.noteDocToken) lines.push(`note_doc_token: ${notes.noteDocToken}`);
    if (notes.verbatimDocToken) lines.push(`verbatim_doc_token: ${notes.verbatimDocToken}`);
    lines.push(`title: ${this.yamlQuote(title)}`);
    lines.push(`date: ${date}`);
    lines.push(`source: ${source}`);
    lines.push(`sync_version: ${PLUGIN_VERSION}`);
    lines.push("sync_status: complete");
    lines.push(`synced_at: ${new Date().toISOString()}`);
    lines.push(`cleaning_skill: ${this.yamlQuote(notes.cleaning.cleaning_skill || "minutes-cleaner")}`);
    lines.push(`cleaning_version: ${this.yamlQuote(notes.cleaning.cleaning_version || "")}`);
    lines.push("cleaning_status: passed");
    lines.push(`cleaned_at: ${this.yamlQuote(notes.cleaning.processed_at || "")}`);
    lines.push(`cleaning_segments: ${Number(notes.cleaning.segment_count || 0)}`);
    lines.push(`cleaning_term_changes: ${Number(notes.cleaning.term_change_count || 0)}`);
    lines.push(`cleaning_oral_changes: ${Number(notes.cleaning.oral_change_count || 0)}`);
    lines.push(`cleaning_ambiguous_preserved: ${Number(notes.cleaning.ambiguous_preserved_count || 0)}`);
    lines.push("tags: [飞书妙记]");
    lines.push("---", "");

    lines.push(`# ${title}`, "");
    if (source) lines.push(`> 妙记链接：[${source}](${source})`);
    if (notes.noteDocToken) lines.push(`> 智能纪要文档：\`${notes.noteDocToken}\``);
    if (notes.verbatimDocToken) lines.push(`> 逐字稿文档：\`${notes.verbatimDocToken}\``);
    const termPreview = (notes.cleaning.term_changes || []).slice(0, 12)
      .map((item) => `\`${item.from}\`→\`${item.to}\`（${item.count}）`).join("、");
    const ambiguousPreview = (notes.cleaning.ambiguous_preserved || []).slice(0, 12)
      .map((item) => `\`${item.form}\``).join("、");
    lines.push(`> 入库清洗：\`${notes.cleaning.cleaning_version}\` 已通过；术语校准 ${Number(notes.cleaning.term_change_count || 0)} 处，口语轻清理 ${Number(notes.cleaning.oral_change_count || 0)} 处，歧义保留 ${Number(notes.cleaning.ambiguous_preserved_count || 0)} 处。`);
    if (termPreview) lines.push(`> 明确校准：${termPreview}`);
    if (ambiguousPreview) lines.push(`> 未自动修改：${ambiguousPreview}${(notes.cleaning.ambiguous_preserved || []).length > 12 ? " 等" : ""}`);
    lines.push("");

    if (notes.smartDocMarkdown) {
      lines.push("## 飞书智能纪要原文（含图文/待办/决策/金句）", "");
      lines.push("> 来源：`note_doc_token` 对应的飞书智能纪要 Docx；图片和画板已尽量下载为本地 Obsidian 附件。", "");
      lines.push(notes.smartDocMarkdown, "");
    } else {
      const fallback = this.buildArtifactSections(notes.artifacts, source);
      if (fallback.trim()) lines.push(fallback, "");
    }

    if (this.settings.includeSummary && notes.summary) {
      lines.push("## AI 总结", "", notes.summary, "");
    }
    if (this.settings.includeTranscript && notes.transcript) {
      lines.push("## 逐字稿", "", notes.transcript, "");
    }
    if (!notes.smartDocMarkdown && !notes.summary && !notes.transcript) {
      lines.push("> （暂无逐字稿/总结内容）", "");
    }
    return lines.join("\n");
  }

  buildArtifactSections(artifacts, source) {
    const lines = [];
    const todos = artifacts && artifacts.todos || artifacts && artifacts.minute_todos || [];
    const chapters = artifacts && artifacts.chapters || artifacts && artifacts.minute_chapters || [];
    const keywords = artifacts && artifacts.keywords || [];

    if (todos.length) {
      lines.push("## 飞书待办", "");
      for (const todo of todos) {
        const text = typeof todo === "string" ? todo : todo.content || this.extractText(todo);
        if (text) lines.push(`- [ ] ${text}`);
      }
      lines.push("");
    }
    if (chapters.length) {
      lines.push("## 智能章节", "");
      for (const chapter of chapters) {
        const startMs = Number(chapter.start_ms || 0);
        const time = this.msToTimestamp(startMs);
        const link = source ? `[${time}](${source}?t=${startMs})` : time;
        lines.push(`### ${link} ${chapter.title || "未命名章节"}`, "", chapter.summary_content || chapter.summary || "", "");
      }
    }
    if (keywords.length) {
      lines.push("## 关键词", "", keywords.map((k) => `#${String(k).replace(/\s+/g, "")}`).join(" "), "");
    }
    return lines.join("\n");
  }

  async findExistingMinuteFile(token) {
    const folder = normalizePath(this.settings.syncFolder);
    const abstract = this.app.vault.getAbstractFileByPath(folder);
    if (!abstract || !abstract.children) return null;
    for (const child of this.getMarkdownFilesRecursively(abstract)) {
      const cache = this.app.metadataCache.getFileCache(child);
      if (cache && cache.frontmatter && cache.frontmatter.minute_token === token) return child;
      try {
        const text = await this.app.vault.cachedRead(child);
        if (new RegExp(`minute_token:\\s*${this.escapeRegExp(token)}\\b`).test(text)) return child;
      } catch (_) {}
    }
    return null;
  }

  getMarkdownFilesRecursively(root) {
    const files = [];
    const visited = new Set();
    const walk = (node) => {
      if (!node || visited.has(node.path)) return;
      visited.add(node.path);
      for (const child of node.children || []) {
        if (child instanceof TFile) {
          if (child.extension === "md") files.push(child);
        } else if (child && child.children) {
          walk(child);
        }
      }
    };
    walk(root);
    return files;
  }

  getMeetingFolder(value, groupingValue) {
    const base = normalizePath(String(this.settings.syncFolder || "").trim() || "FeishuMinutes");
    const requestedGrouping = groupingValue == null ? this.settings.folderGrouping : groupingValue;
    const grouping = new Set(["year", "month", "week"]).has(requestedGrouping)
      ? requestedGrouping
      : "none";
    if (grouping === "none") return base;

    let date = this.parseMeetingDate(value);
    if (Number.isNaN(date.getTime())) date = new Date();
    const year = String(date.getFullYear());
    if (grouping === "year") return normalizePath(`${base}/${year}`);
    if (grouping === "month") {
      const month = String(date.getMonth() + 1).padStart(2, "0");
      return normalizePath(`${base}/${year}/${month}`);
    }

    const isoWeek = this.getIsoWeek(date);
    return normalizePath(`${base}/${isoWeek.year}/W${String(isoWeek.week).padStart(2, "0")}`);
  }

  getIsoWeek(value) {
    const date = new Date(value);
    const utcDate = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()));
    const day = utcDate.getUTCDay() || 7;
    utcDate.setUTCDate(utcDate.getUTCDate() + 4 - day);
    const year = utcDate.getUTCFullYear();
    const yearStart = new Date(Date.UTC(year, 0, 1));
    const week = Math.ceil((((utcDate - yearStart) / 86400000) + 1) / 7);
    return { year, week };
  }

  parseMeetingDate(value, fallbackName) {
    const text = String(value == null ? "" : value).trim();
    const match = text.match(/(\d{4})-(\d{1,2})-(\d{1,2})/)
      || String(fallbackName || "").match(/^(\d{4})-(\d{1,2})-(\d{1,2})/);
    if (match) {
      const year = Number(match[1]);
      const month = Number(match[2]);
      const day = Number(match[3]);
      const date = new Date(year, month - 1, day);
      if (date.getFullYear() === year && date.getMonth() === month - 1 && date.getDate() === day) {
        return date;
      }
    }
    const date = new Date(value);
    return Number.isNaN(date.getTime()) ? new Date(NaN) : date;
  }

  async getMinuteFileOrganizationMetadata(file) {
    const cache = this.app.metadataCache.getFileCache(file);
    const fm = (cache && cache.frontmatter) || {};
    let token = String(fm.minute_token || "").trim();
    let dateValue = fm.date == null ? "" : String(fm.date).trim();
    if (!token || !dateValue) {
      try {
        const text = await this.app.vault.cachedRead(file);
        if (!token) {
          const tokenMatch = text.match(/^minute_token:\s*["']?([^\s"']+)["']?\s*$/m);
          token = tokenMatch ? tokenMatch[1] : "";
        }
        if (!dateValue) {
          const dateMatch = text.match(/^date:\s*["']?(\d{4}-\d{1,2}-\d{1,2})["']?\s*$/m);
          dateValue = dateMatch ? dateMatch[1] : "";
        }
      } catch (_) {}
    }
    if (!token || token === "飞书妙记唯一") return null;
    const date = this.parseMeetingDate(dateValue, file.basename);
    if (Number.isNaN(date.getTime())) return { token, date: null };
    return { token, date };
  }

  async uniqueMinuteTargetPath(targetPath, token) {
    let candidate = normalizePath(targetPath);
    if (!this.app.vault.getAbstractFileByPath(candidate)) return candidate;
    const dot = candidate.toLowerCase().endsWith(".md") ? candidate.length - 3 : candidate.length;
    const stem = candidate.slice(0, dot);
    const extension = candidate.slice(dot);
    const tokenSuffix = this.sanitize(String(token || "").slice(-6)) || "duplicate";
    candidate = normalizePath(`${stem} ${tokenSuffix}${extension}`);
    if (!this.app.vault.getAbstractFileByPath(candidate)) return candidate;
    for (let i = 2; i < 1000; i += 1) {
      candidate = normalizePath(`${stem} ${tokenSuffix}-${i}${extension}`);
      if (!this.app.vault.getAbstractFileByPath(candidate)) return candidate;
    }
    return normalizePath(`${stem} ${tokenSuffix}-${Date.now()}${extension}`);
  }

  getFolderGroupingLabel(grouping) {
    return ({ none: "不分类", year: "按年", month: "按月", week: "按周" })[grouping] || "不分类";
  }

  async organizeExistingNotes(manual) {
    if (this.organizing) {
      if (manual) new Notice("已有会议纪要正在整理中…");
      return { moved: 0, unchanged: 0, failed: 0, undated: 0, busy: true };
    }
    this.organizing = true;
    const grouping = new Set(["year", "month", "week"]).has(this.settings.folderGrouping)
      ? this.settings.folderGrouping
      : "none";
    const label = this.getFolderGroupingLabel(grouping);
    try {
      const rootPath = normalizePath(String(this.settings.syncFolder || "").trim() || "FeishuMinutes");
      const root = this.app.vault.getAbstractFileByPath(rootPath);
      if (!root || !root.children) {
        if (manual) new Notice(`找不到妙记文件夹：${rootPath}`);
        return { moved: 0, unchanged: 0, failed: 0, undated: 0, missingRoot: true };
      }

      const candidates = [];
      let undated = 0;
      for (const file of this.getMarkdownFilesRecursively(root)) {
        const metadata = await this.getMinuteFileOrganizationMetadata(file);
        if (!metadata) continue;
        if (!metadata.date) {
          undated += 1;
          continue;
        }
        candidates.push({ file, metadata });
      }
      if (manual) new Notice(`正在${label}整理 ${candidates.length} 条已有会议纪要…`);

      let moved = 0;
      let unchanged = 0;
      let failed = 0;
      for (const { file, metadata } of candidates) {
        const targetFolder = this.getMeetingFolder(metadata.date, grouping);
        const fileName = file.name || `${file.basename}.${file.extension}`;
        const desiredPath = normalizePath(`${targetFolder}/${fileName}`);
        if (desiredPath === file.path) {
          unchanged += 1;
          continue;
        }
        try {
          await this.ensureFolder(targetFolder);
          const targetPath = await this.uniqueMinuteTargetPath(desiredPath, metadata.token);
          if (this.app.fileManager && typeof this.app.fileManager.renameFile === "function") {
            await this.app.fileManager.renameFile(file, targetPath);
          } else if (typeof this.app.vault.rename === "function") {
            await this.app.vault.rename(file, targetPath);
          } else {
            throw new Error("当前 Obsidian 不支持安全移动文件");
          }
          moved += 1;
        } catch (err) {
          failed += 1;
          this.log("整理已有妙记失败", file.path, err);
        }
      }

      this.settings.lastFolderOrganization = {
        grouping,
        organizedAt: new Date().toISOString(),
        moved,
        unchanged,
        failed,
        undated,
      };
      await this.saveSettings();
      if (manual) {
        new Notice(`已有纪要${label}整理完成：移动 ${moved} 条，原位 ${unchanged} 条${undated ? `，缺少日期 ${undated} 条` : ""}${failed ? `，失败 ${failed} 条` : ""}`, 12000);
      }
      return { moved, unchanged, failed, undated };
    } finally {
      this.organizing = false;
    }
  }

  async isFileContentComplete(file) {
    try {
      const text = await this.app.vault.cachedRead(file);
      if (text.includes("暂无逐字稿/总结内容")) return false;
      return /^(## 飞书智能纪要原文（含图文\/待办\/决策\/金句）|## AI 总结|## 逐字稿|## 智能章节|## 飞书待办|## 总结|## 待办|## 关键决策|## 其他决策)/m.test(text);
    } catch (_) {
      return false;
    }
  }

  parseMediaFromXml(xml) {
    const images = [];
    const whiteboards = [];
    if (!xml) return { images, whiteboards };

    // 按文档顺序保留每个 <img>，与 markdown 里的图片一一对应。
    // src 是持久 file_token（可走 media-download）；href 带 authcode，几分钟后过期，不可用。
    const imgRegex = /<img\b[^>]*>/g;
    let imgMatch;
    while ((imgMatch = imgRegex.exec(xml))) {
      const attrs = this.parseAttrs(imgMatch[0]);
      images.push({
        fileToken: attrs.src || "",
        href: attrs.href || "", // 与 markdown 图片 URL 相同（同次抓取的 authcode 直链），用作强匹配键
        caption: this.cleanCaption(attrs.caption),
        name: attrs.name || "",
        mime: attrs.mime || "image/png",
      });
    }

    const wbRegex = /<whiteboard\b[^>]*>/g;
    let wbMatch;
    while ((wbMatch = wbRegex.exec(xml))) {
      const attrs = this.parseAttrs(wbMatch[0]);
      if (attrs.token) whiteboards.push({ token: attrs.token, caption: this.cleanCaption(attrs.caption) || "智能纪要画板" });
    }
    return { images, whiteboards };
  }

  cleanCaption(value) {
    return String(value || "").replace(/\s+/g, " ").trim();
  }

  parseAttrs(tag) {
    const attrs = {};
    const regex = /([\w:-]+)="([^"]*)"/g;
    let match;
    while ((match = regex.exec(tag))) {
      attrs[match[1]] = this.decodeEntities(match[2]);
    }
    return attrs;
  }

  async localizeSmartDocMedia(markdown, xml, minuteToken, title, tmpDir) {
    const { images, whiteboards } = this.parseMediaFromXml(xml);
    let output = markdown;
    await this.ensureFolder(this.settings.attachmentFolder);
    await this.ensureFolder(`${this.settings.attachmentFolder}/${minuteToken}`);

    // ----- 图片：按文档顺序，用 XML 的 src(file_token) 走 media-download，持久不依赖 authcode -----
    if (this.settings.includeImages) {
      // 优先用 href 强匹配（md 图片 URL === XML <img href>，同次抓取一致），下标仅作兜底，
      // 避免极端情况下 md 图片数 != XML <img> 数时按下标错位“串图”。
      const hrefToMeta = new Map();
      for (const im of images) if (im.href) hrefToMeta.set(im.href, im);
      const mdImgRe = /!\[([^\]]*)\]\(([^)]+)\)/g;
      const jobs = [];
      let m, i = 0;
      while ((m = mdImgRe.exec(output))) {
        const meta = hrefToMeta.get(m[2]) || images[i] || {};
        jobs.push({ alt: m[1], url: m[2], index: i, fileToken: meta.fileToken, caption: meta.caption });
        i += 1;
      }
      if (i !== images.length) {
        this.log(`警告：markdown 图片数 ${i} 与 XML <img> 数 ${images.length} 不一致，已用 href 强匹配兜底定位`);
      }
      for (const job of jobs) {
        if (!job.fileToken) { this.log("图片缺少 src(file_token)，跳过", job.index); continue; }
        try {
          job.local = await this.downloadDocMedia({
            token: job.fileToken,
            type: "media",
            minuteToken,
            title,
            index: job.index + 1,
            caption: job.caption || `图片 ${job.index + 1}`,
            tmpDir,
          });
        } catch (err) {
          this.log("下载图片失败", job.fileToken, err);
        }
      }
      let k = 0;
      output = output.replace(mdImgRe, (full, alt, url) => {
        const job = jobs[k++];
        if (!job || !job.local) return full;
        const cap = (alt && alt.trim()) || job.caption;
        return `![[${job.local}]]${cap ? `\n> 图：${cap}` : ""}`;
      });
    }

    // ----- 画板：用 token 走 media-download --type whiteboard -----
    if (this.settings.includeWhiteboards) {
      const tokens = [];
      const tagRegex = /<whiteboard\b[^>]*token="([^"]+)"[\s\S]*?<\/whiteboard>/g;
      let tagMatch;
      while ((tagMatch = tagRegex.exec(markdown))) if (!tokens.includes(tagMatch[1])) tokens.push(tagMatch[1]);
      for (const wb of whiteboards) if (wb.token && !tokens.includes(wb.token)) tokens.push(wb.token);

      const tokenToLocal = new Map();
      let index = 1;
      for (const token of tokens) {
        try {
          tokenToLocal.set(token, await this.downloadDocMedia({
            token,
            type: "whiteboard",
            minuteToken,
            title,
            index,
            caption: "画板",
            tmpDir,
          }));
          index += 1;
        } catch (err) {
          this.log("下载画板失败", token, err);
        }
      }
      output = output.replace(tagRegex, (full, token) => {
        const localPath = tokenToLocal.get(token);
        return localPath ? `![[${localPath}]]\n> 画板` : full;
      });
    }

    return output;
  }

  async downloadDocMedia({ token, type, minuteToken, index, caption, tmpDir }) {
    const baseName = `${String(index).padStart(2, "0")}-${this.sanitize(caption || token).slice(0, 40) || token}`;
    // 注意：docs +media-download 不支持 --format（会报 unknown flag）；默认输出即 JSON，runCli 能解析
    const response = await this.runCli([
      "docs", "+media-download",
      "--as", "user",
      "--token", token,
      "--type", type,
      "--output", baseName,
      "--overwrite",
    ], tmpDir);
    if (!response || !response.ok || !response.data || !response.data.saved_path) {
      throw new Error(`media-download failed: ${JSON.stringify(response).slice(0, 500)}`);
    }
    const savedPath = response.data.saved_path;
    let buffer = fs.readFileSync(savedPath);
    const contentType = response.data.content_type || "";
    const ext = path.extname(savedPath) || this.extFromMime(contentType) || ".bin";
    // 画板导出是固定 2560x2560 正方形，内容多在一隅、四周大片白边；裁掉白边只保留内容区
    buffer = await this.trimImageBuffer(buffer, contentType || this.mimeFromExt(ext));
    const vaultPath = normalizePath(`${this.settings.attachmentFolder}/${minuteToken}/${baseName}${ext}`);
    if (!this.app.vault.getAbstractFileByPath(vaultPath)) {
      await this.writeBinary(vaultPath, buffer);
    }
    return vaultPath;
  }

  mimeFromExt(ext) {
    const e = String(ext || "").toLowerCase();
    if (e.includes("png")) return "image/png";
    if (e.includes("jpg") || e.includes("jpeg")) return "image/jpeg";
    if (e.includes("gif")) return "image/gif";
    if (e.includes("webp")) return "image/webp";
    return "image/png";
  }

  // 用 Canvas 裁掉图片四周纯白边（Obsidian 是 Electron，必有 Canvas）。
  // 算法与 Python 验证版一致：任一 RGB 通道 < 248 视为非白，逐边收敛 + 16px padding。
  // node 等无 document 环境优雅降级返回原图（集成测试照常跑通）。
  async trimImageBuffer(buffer, mime) {
    if (this.settings.trimImageWhitespace === false) return buffer;
    if (typeof document === "undefined" || typeof Image === "undefined" || typeof URL === "undefined") return buffer;
    let url;
    try {
      const blob = new Blob([buffer], { type: mime || "image/png" });
      url = URL.createObjectURL(blob);
      const img = await new Promise((resolve, reject) => {
        const im = new Image();
        im.onload = () => resolve(im);
        im.onerror = () => reject(new Error("image decode failed"));
        im.src = url;
      });
      const w = img.naturalWidth, h = img.naturalHeight;
      if (!w || !h) return buffer;
      const canvas = document.createElement("canvas");
      canvas.width = w; canvas.height = h;
      const ctx = canvas.getContext("2d");
      ctx.drawImage(img, 0, 0);
      const data = ctx.getImageData(0, 0, w, h).data;
      const TH = 248, PAD = 16;
      const nonBlank = (x, y) => {
        const i = (y * w + x) * 4;
        if (data[i + 3] < 10) return false; // 透明视为空
        return data[i] < TH || data[i + 1] < TH || data[i + 2] < TH;
      };
      let top = 0, bottom = h - 1, left = 0, right = w - 1;
      const rowHas = (y) => { for (let x = 0; x < w; x++) if (nonBlank(x, y)) return true; return false; };
      const colHas = (x) => { for (let y = top; y <= bottom; y++) if (nonBlank(x, y)) return true; return false; };
      while (top < bottom && !rowHas(top)) top++;
      while (bottom > top && !rowHas(bottom)) bottom--;
      while (left < right && !colHas(left)) left++;
      while (right > left && !colHas(right)) right--;
      top = Math.max(0, top - PAD); left = Math.max(0, left - PAD);
      bottom = Math.min(h - 1, bottom + PAD); right = Math.min(w - 1, right + PAD);
      const cw = right - left + 1, ch = bottom - top + 1;
      if (cw <= 0 || ch <= 0 || (cw >= w && ch >= h)) return buffer; // 没有可裁的白边
      const out = document.createElement("canvas");
      out.width = cw; out.height = ch;
      out.getContext("2d").drawImage(canvas, left, top, cw, ch, 0, 0, cw, ch);
      const isJpg = /jpe?g/i.test(mime || "");
      const dataUrl = out.toDataURL(isJpg ? "image/jpeg" : "image/png", isJpg ? 0.92 : undefined);
      const b64 = (dataUrl.split(",")[1]) || "";
      if (!b64) return buffer;
      this.log(`裁白边 ${w}x${h} -> ${cw}x${ch}`);
      return Buffer.from(b64, "base64");
    } catch (err) {
      this.log("裁白边失败，保留原图", err);
      return buffer;
    } finally {
      if (url) URL.revokeObjectURL(url);
    }
  }

  async writeBinary(vaultPath, buffer) {
    const parent = path.posix.dirname(vaultPath);
    await this.ensureFolder(parent);
    const arrayBuffer = buffer.buffer.slice(buffer.byteOffset, buffer.byteOffset + buffer.byteLength);
    await this.app.vault.adapter.writeBinary(vaultPath, arrayBuffer);
  }

  normalizeSmartMarkdown(markdown) {
    let text = markdown || "";
    text = text.replace(/<title>[\s\S]*?<\/title>\s*/g, "");
    text = text.replace(/<readonly-block\b[^>]*>\s*<\/readonly-block>\s*/g, "");
    text = text.replace(/<readonly-block\b[^>]*\/>\s*/g, "");
    text = text.replace(/<\/?grid\b[^>]*>/g, "");
    text = text.replace(/<\/?column\b[^>]*>/g, "");
    // 兜底：清除任何未被本地化替换的残留画板标签，避免裸 <whiteboard> 暴露在正文
    text = text.replace(/<whiteboard\b[^>]*>[\s\S]*?<\/whiteboard>\s*/g, "");
    text = text.replace(/<whiteboard\b[^>]*\/>\s*/g, "");
    text = text.replace(/^# /gm, "## ");
    text = text.replace(/\n{3,}/g, "\n\n");
    return text.trim();
  }

  // 按 ## 章节切分智能纪要，根据各模块开关过滤；未识别章节默认保留
  filterSmartSections(markdown) {
    if (!markdown) return markdown;
    const titleToKey = {
      "总结": "includeSmartSummary",
      "待办": "includeTodos",
      "智能章节": "includeChapters",
      "关键决策": "includeDecisions",
      "其他决策": "includeDecisions",
      "金句时刻": "includeHighlights",
      "相关链接": "includeLinks",
    };
    const lines = markdown.split("\n");
    const blocks = [];
    let cur = { title: null, lines: [] };
    for (const line of lines) {
      const m = line.match(/^##\s+(.+?)\s*$/);
      if (m) {
        blocks.push(cur);
        cur = { title: m[1].trim(), lines: [line] };
      } else {
        cur.lines.push(line);
      }
    }
    blocks.push(cur);
    const kept = blocks.filter((b) => {
      if (!b.title) return true; // 头部（录音主题/时间等）保留
      const key = titleToKey[b.title];
      if (!key) return true; // 未识别章节默认保留，避免误删
      return this.settings[key] !== false;
    });
    return kept.map((b) => b.lines.join("\n")).join("\n").replace(/\n{3,}/g, "\n\n").trim();
  }

  async ensureFolder(folderPath) {
    const clean = normalizePath(folderPath);
    if (!clean || clean === ".") return;
    const parts = clean.split("/");
    let current = "";
    for (const part of parts) {
      current = current ? `${current}/${part}` : part;
      if (!this.app.vault.getAbstractFileByPath(current)) {
        try { await this.app.vault.createFolder(current); } catch (_) {}
      }
    }
  }

  async uniquePath(basePath) {
    let candidate = normalizePath(basePath);
    if (!this.app.vault.getAbstractFileByPath(candidate)) return candidate;
    for (let i = 2; i < 1000; i += 1) {
      candidate = normalizePath(`${basePath}-${i}`);
      if (!this.app.vault.getAbstractFileByPath(candidate)) return candidate;
    }
    return normalizePath(`${basePath}-${Date.now()}`);
  }

  timestamp() {
    const d = new Date();
    const pad = (n) => String(n).padStart(2, "0");
    return `${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}-${pad(d.getHours())}${pad(d.getMinutes())}${pad(d.getSeconds())}`;
  }

  sanitize(value) {
    return String(value || "")
      .replace(/[\\/:*?"<>|#^\[\]]/g, " ")
      .replace(/\s+/g, " ")
      .trim()
      .slice(0, 80);
  }

  yamlQuote(value) {
    const s = String(value || "").replace(/"/g, "\\\"");
    return `"${s}"`;
  }

  fmtDate(value) {
    const d = new Date(value);
    const pad = (n) => String(n).padStart(2, "0");
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  }

  parseStartMs(item) {
    const meta = item && item.meta_data || {};
    const text = `${item && item.display_info || ""} ${meta.description || ""}`;
    let match = text.match(/(\d{4})[.\-/](\d{1,2})[.\-/](\d{1,2})\s+(\d{1,2}):(\d{2})(?::(\d{2}))?/);
    if (match) {
      const d = new Date(+match[1], +match[2] - 1, +match[3], +match[4], +match[5], +(match[6] || 0));
      if (!Number.isNaN(d.getTime())) return d.getTime();
    }
    match = text.match(/(\d{4})[.\-/](\d{1,2})[.\-/](\d{1,2})/);
    if (match) {
      const d = new Date(+match[1], +match[2] - 1, +match[3]);
      if (!Number.isNaN(d.getTime())) return d.getTime();
    }
    return undefined;
  }

  msToTimestamp(ms) {
    const totalSeconds = Math.floor(Number(ms || 0) / 1000);
    const h = Math.floor(totalSeconds / 3600);
    const m = Math.floor((totalSeconds % 3600) / 60);
    const s = totalSeconds % 60;
    const pad = (n) => String(n).padStart(2, "0");
    return h ? `${pad(h)}:${pad(m)}:${pad(s)}` : `${pad(m)}:${pad(s)}`;
  }

  extFromMime(mime) {
    if (!mime) return "";
    if (mime.includes("png")) return ".png";
    if (mime.includes("jpeg") || mime.includes("jpg")) return ".jpg";
    if (mime.includes("gif")) return ".gif";
    if (mime.includes("webp")) return ".webp";
    return "";
  }

  decodeEntities(value) {
    return String(value || "")
      .replace(/&#x([0-9a-fA-F]+);/g, (_, hex) => String.fromCodePoint(parseInt(hex, 16)))
      .replace(/&#(\d+);/g, (_, dec) => String.fromCodePoint(parseInt(dec, 10)))
      .replace(/&quot;/g, '"')
      .replace(/&amp;/g, "&")
      .replace(/&lt;/g, "<")
      .replace(/&gt;/g, ">");
  }

  escapeRegExp(value) {
    return String(value).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  }
}

class FeishuMinutesSettingTab extends PluginSettingTab {
  constructor(app, plugin) {
    super(app, plugin);
    this.plugin = plugin;
  }

  display() {
    const { containerEl } = this;
    containerEl.empty();
    containerEl.createEl("h2", { text: "飞书妙记同步（基于 lark-cli）" });
    containerEl.createEl("p", {
      text: "v0.2.0 起优先同步 note_doc_token 对应的飞书智能纪要 Docx，可拉取图文、画板、待办、智能章节、关键决策、其他决策和金句时刻。",
      cls: "fms-section-desc",
    });

    new Setting(containerEl)
      .setName("lark-cli 路径")
      .setDesc("留空自动探测")
      .addText((text) => text
        .setPlaceholder("/opt/homebrew/opt/node@22/bin/lark-cli")
        .setValue(this.plugin.settings.cliPath)
        .onChange(async (value) => {
          this.plugin.settings.cliPath = value.trim();
          await this.plugin.saveSettings();
        }));

    new Setting(containerEl)
      .setName("检查并修复")
      .setDesc("一次点击自动补全 lark-cli 路径、修复 macOS 后台授权并复检 8 项权限；只有飞书要求本人确认时才会打开授权页面。不会读取或上传 token。")
      .addButton((button) => button
        .setButtonText(this.plugin.authRepairMonitorId == null ? "检查并修复" : "修复进行中…")
        .setCta()
        .setDisabled(this.plugin.authRepairMonitorId != null)
        .onClick(async () => {
          button.setDisabled(true).setButtonText("正在检查…");
          try {
            const result = await this.plugin.checkAndRepairCli();
            if (result && result.action === "repair_launched") {
              button.setButtonText("修复进行中…");
            } else {
              button.setDisabled(false).setButtonText("检查并修复");
            }
          } catch (err) {
            button.setDisabled(false).setButtonText("检查并修复");
            new Notice(`检查失败：${err.message}`, 15000);
          }
        }));

    const backgroundAuth = this.plugin.getBackgroundAuthCompatibility();
    if (backgroundAuth.applicable) {
      let backgroundDesc;
      if (backgroundAuth.ok) {
        backgroundDesc = "已启用文件主密钥模式，Obsidian/LaunchAgent 无需直接读取系统钥匙串。";
      } else if (backgroundAuth.fileBacked && !backgroundAuth.securePermissions) {
        backgroundDesc = "主密钥文件已存在，但权限不够安全；请修复为仅当前用户可读写。";
      } else if (backgroundAuth.hasCredentialFiles) {
        backgroundDesc = "检测到本地授权，但仍依赖系统钥匙串；后台进程可能被拦截并误报 token 缺失。";
      } else {
        backgroundDesc = "授权完成后建议启用，避免 Obsidian 后台进程被 macOS 钥匙串拦截。";
      }
      new Setting(containerEl)
        .setName("macOS 后台授权")
        .setDesc(backgroundDesc)
        .addButton((button) => {
          button.setButtonText(backgroundAuth.ok ? "重新检查" : "随主检查修复");
          if (!backgroundAuth.ok) button.setCta();
          button.onClick(() => this.plugin.checkAndRepairCli());
        });
    }

    containerEl.createEl("h3", { text: "同步设置" });
    new Setting(containerEl)
      .setName("存放文件夹")
      .addText((text) => text.setValue(this.plugin.settings.syncFolder).onChange(async (value) => {
        this.plugin.settings.syncFolder = value.trim() || "FeishuMinutes";
        await this.plugin.saveSettings();
      }));

    new Setting(containerEl)
      .setName("会议纪要目录分类")
      .setDesc("选择后会立即整理已有会议纪要，之后同步的新纪要也按同一规则存放；附件和备份不移动。")
      .addDropdown((dropdown) => dropdown
        .addOption("none", "不分类（保持原目录）")
        .addOption("year", "按年（如 2026）")
        .addOption("month", "按月（如 2026/08）")
        .addOption("week", "按周（如 2026/W33）")
        .setValue(this.plugin.settings.folderGrouping)
        .onChange(async (value) => {
          this.plugin.settings.folderGrouping = value;
          await this.plugin.saveSettings();
          await this.plugin.organizeExistingNotes(true);
        }));

    new Setting(containerEl)
      .setName("重新整理已有纪要")
      .setDesc("按上方当前分类重新检查全部已有妙记；通过 Obsidian 安全移动文件并同步更新内部链接。")
      .addButton((button) => button
        .setButtonText("立即整理")
        .onClick(async () => {
          button.setDisabled(true).setButtonText("整理中…");
          try {
            await this.plugin.organizeExistingNotes(true);
          } finally {
            button.setDisabled(false).setButtonText("立即整理");
          }
        }));

    new Setting(containerEl)
      .setName("附件文件夹")
      .setDesc("图片、画板缩略图会保存到这里，默认按 minute_token 分子文件夹")
      .addText((text) => text.setValue(this.plugin.settings.attachmentFolder).onChange(async (value) => {
        this.plugin.settings.attachmentFolder = value.trim() || "01-会议纪要/FeishuMinutes/assets";
        await this.plugin.saveSettings();
      }));

    new Setting(containerEl)
      .setName("Minutes Cleaner 入库门禁")
      .setDesc("强制启用：默认使用插件内置脚本；完整逐字稿清洗和结构校验通过后才写入 Obsidian，失败时不会创建或更新纪要。")
      .addText((text) => text.setValue(this.plugin.settings.minutesCleanerScript).onChange(async (value) => {
        this.plugin.settings.minutesCleanerScript = value.trim();
        await this.plugin.saveSettings();
      }));

    new Setting(containerEl)
      .setName("Minutes Cleaner 术语表")
      .setDesc("默认使用插件内置术语表；保护词、冲突词和高歧义词会保留原文。")
      .addText((text) => text.setValue(this.plugin.settings.minutesCleanerGlossary).onChange(async (value) => {
        this.plugin.settings.minutesCleanerGlossary = value.trim();
        await this.plugin.saveSettings();
      }));

    new Setting(containerEl)
      .setName("自动同步")
      .setDesc("Obsidian 开着时按间隔定时同步")
      .addToggle((toggle) => toggle.setValue(this.plugin.settings.autoSync).onChange(async (value) => {
        this.plugin.settings.autoSync = value;
        await this.plugin.saveSettings();
        new Notice("重启 Obsidian 后生效");
      }));

    new Setting(containerEl)
      .setName("轮询间隔（分钟）")
      .addText((text) => text.setValue(String(this.plugin.settings.pollIntervalMinutes)).onChange(async (value) => {
        const n = parseInt(value, 10);
        if (!Number.isNaN(n) && n >= 5) {
          this.plugin.settings.pollIntervalMinutes = n;
          await this.plugin.saveSettings();
        }
      }));

    new Setting(containerEl)
      .setName("回看天数")
      .setDesc("每次往回搜索最近多少天")
      .addText((text) => text.setValue(String(this.plugin.settings.lookbackDays)).onChange(async (value) => {
        const n = parseInt(value, 10);
        if (!Number.isNaN(n) && n >= 1 && n <= 730) {
          this.plugin.settings.lookbackDays = n;
          await this.plugin.saveSettings();
        }
      }));

    containerEl.createEl("h3", { text: "内容模块" });
    this.addToggle("同步飞书智能纪要 Docx", "总开关：关掉则不抓智能纪要，仅保留 AI 总结/逐字稿", "includeSmartDoc");
    containerEl.createEl("p", { text: "智能纪要内各模块（上面总开关开启时生效）：", cls: "fms-section-desc" });
    this.addToggle("　└ 总结", "智能纪要的总结段（通常含画板/图）", "includeSmartSummary");
    this.addToggle("　└ 待办", "智能纪要的待办清单", "includeTodos");
    this.addToggle("　└ 智能章节", "带时间戳的分章节摘要", "includeChapters");
    this.addToggle("　└ 关键决策 / 其他决策", "决策模块", "includeDecisions");
    this.addToggle("　└ 金句时刻", "金句时刻", "includeHighlights");
    this.addToggle("　└ 相关链接", "妙记/逐字稿文档链接", "includeLinks");
    this.addToggle("下载图片到本地", "把飞书图片转成 Obsidian ![[附件]]，避免链接过期", "includeImages");
    this.addToggle("下载画板缩略图", "把 whiteboard token 下载为本地 jpg/png", "includeWhiteboards");
    this.addToggle("裁掉图片白边", "画板导出是 2560 正方形大白边；自动裁到内容区，去掉冗余空白", "trimImageWhitespace");
    this.addToggle("包含 AI 总结（纯文本）", "artifacts 里的纯文本总结，兼容自动台账脚本", "includeSummary");
    this.addToggle("包含逐字稿", "同步完整逐字稿", "includeTranscript");
    this.addToggle("自动修复正文不完整的笔记", "默认开启；只重试链接占位/正文缺失的妙记，不覆盖正文完整的旧笔记", "updateExisting");
    this.addToggle("补全当前笔记前备份", "使用命令补全当前笔记时，先创建 .bak 备份", "backupBeforeEnrich");
    this.addToggle("调试日志", "在开发者控制台打印 lark-cli 输出片段", "debug");

    containerEl.createEl("h3", { text: "操作" });
    new Setting(containerEl)
      .setName("立即同步")
      .addButton((button) => button.setButtonText("同步一次").setCta().onClick(() => this.plugin.runSync(true)));
    new Setting(containerEl)
      .setName("补全当前打开的妙记")
      .setDesc("只处理当前打开的这一条：补上图文、画板、待办、决策和金句")
      .addButton((button) => button.setButtonText("补全当前笔记").setCta().onClick(() => this.plugin.enrichCurrentFile()));
    new Setting(containerEl)
      .setName("补全所有妙记笔记（批量）")
      .setDesc("遍历妙记文件夹，把所有非最新版的旧笔记补齐缺失的图文/画板/各模块；跳过练习录音和无智能纪要的；每条自动备份")
      .addButton((button) => button.setButtonText("补全全部").setWarning().onClick(() => this.plugin.enrichAllFiles()));
    new Setting(containerEl)
      .setName("清空同步记录")
      .setDesc(`已记录 ${Object.keys(this.plugin.settings.syncedTokens).length} 条`)
      .addButton((button) => button.setButtonText("清空").setWarning().onClick(async () => {
        this.plugin.settings.syncedTokens = {};
        await this.plugin.saveSettings();
        new Notice("已清空同步记录");
        this.display();
      }));
  }

  addToggle(name, desc, key) {
    new Setting(this.containerEl)
      .setName(name)
      .setDesc(desc)
      .addToggle((toggle) => toggle.setValue(!!this.plugin.settings[key]).onChange(async (value) => {
        this.plugin.settings[key] = value;
        await this.plugin.saveSettings();
      }));
  }
}

module.exports = FeishuMinutesSyncPlugin;
module.exports.default = FeishuMinutesSyncPlugin;
