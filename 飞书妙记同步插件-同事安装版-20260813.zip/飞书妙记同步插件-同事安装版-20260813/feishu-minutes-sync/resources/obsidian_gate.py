#!/usr/bin/env python3
"""Conservative transcript gate for unattended Obsidian ingestion."""

import argparse
import datetime as dt
import hashlib
import json
import re
from pathlib import Path


VERSION = "minutes-cleaner-v0.4-obsidian-gate"
TABLE_ROW = re.compile(r"^\|(.+)\|\s*$")
FORM_SPLIT = re.compile(r"[、,，/；;]")
SECTION_HEADER = re.compile(r"^##\s+(.+?)\s*$")
CJK = r"\u3400-\u9fff"
SPEAKER_HEADER = re.compile(
    r"^(?:Speaker\s+\S+|说话人\s*\S+)\s+\d{2}:\d{2}:\d{2}(?:\.\d+)?\s*$",
    re.IGNORECASE,
)
LEADING_FILLER = re.compile(r"^\s*(?:(?:嗯|啊|呃|额)[，,、.。！？?!]?\s*)+")
REPEATED_FILLER = re.compile(
    rf"(?<![{CJK}])([嗯啊呃额])(?:[，,、.。]?\s*\1)+(?![{CJK}])"
)
OBVIOUS_STUTTER = re.compile(rf"(?<![{CJK}])([我你他她它这那就])\1{{2,}}(?=[{CJK}])")

# These forms can be ordinary words, roles or names. In unattended mode the
# safer action is to preserve them and record the candidate for review.
LOCAL_AMBIGUOUS_FORMS = {
    "慢慢", "满满", "大问", "海霞", "李岩", "陈玉", "陈立", "老东", "老懂",
    "班主任", "队长", "大摩", "小花", "老黄", "老张", "小同", "小于", "小余",
    "见面", "鲁班", "联防", "剑客", "区间交易", "信用中心", "交通标准高",
    "消防标准高", "单程", "单纯", "电动", "梦", "木马", "奥迪", "普通化",
    "实战", "试站", "山鸡", "班长", "飞哥", "汇聚", "基本法", "火种", "翻山",
}


def split_forms(value):
    values = []
    for item in FORM_SPLIT.split(value):
        item = re.sub(r"（.*?）|\(.*?\)", "", item).strip()
        if item and item not in ("—", "-"):
            values.append(item)
    return values


def parse_glossary(path):
    mappings = {}
    mapping_scopes = {}
    conflicts = set()
    protected = set()
    headers = None
    section = ""
    for line in Path(path).read_text(encoding="utf-8").splitlines():
        section_match = SECTION_HEADER.match(line)
        if section_match:
            section = section_match.group(1).strip()
            headers = None
            continue
        match = TABLE_ROW.match(line)
        if not match:
            headers = None
            continue
        cells = [cell.strip() for cell in match.group(1).split("|")]
        if all(re.fullmatch(r":?-+:?", cell) for cell in cells):
            continue
        lowered = [cell.lower() for cell in cells]
        if "target" in lowered and "protected_forms" in lowered:
            headers = lowered
            continue
        if "canonical" in lowered and "variants" in lowered:
            headers = lowered
            continue
        if not headers or len(cells) != len(headers):
            continue
        row = dict(zip(headers, cells))
        if "protected_forms" in row:
            protected.update(split_forms(row.get("protected_forms", "")))
            continue
        if section.startswith("三、"):
            mapping_scope = "business_term"
        elif section.startswith("五、人物 ASR 自动校准白名单"):
            mapping_scope = "person_asr_whitelist"
        else:
            # 第二节人物档案只用于识别参考，不参与正文替换。
            continue
        canonical = row.get("canonical", "").strip()
        variants = row.get("variants", "").strip()
        if not canonical or variants in ("", "—", "-"):
            continue
        for variant in split_forms(variants):
            if not variant or variant == canonical:
                continue
            if variant in mappings and mappings[variant] != canonical:
                conflicts.add(variant)
            else:
                mappings[variant] = canonical
                mapping_scopes[variant] = mapping_scope
    for variant in conflicts | protected:
        mappings.pop(variant, None)
        mapping_scopes.pop(variant, None)
    return mappings, mapping_scopes, conflicts, protected


def is_cjk(char):
    return bool(char and "\u3400" <= char <= "\u9fff")


def is_ascii_word(char):
    return bool(char and char.isascii() and (char.isalnum() or char == "_"))


def apply_terms(text, mappings, mapping_scopes, stats):
    if not mappings or not text:
        return text
    variants = sorted(mappings, key=len, reverse=True)
    pattern = re.compile("|".join(re.escape(item) for item in variants))

    def replace(match):
        variant = match.group(0)
        canonical = mappings[variant]
        mapping_scope = mapping_scopes.get(variant, "")
        is_confirmed_person_asr = mapping_scope == "person_asr_whitelist"
        before = text[match.start() - 1] if match.start() else ""
        after = text[match.end()] if match.end() < len(text) else ""
        contains_cjk = any(is_cjk(char) for char in variant)
        reason = ""

        if variant in LOCAL_AMBIGUOUS_FORMS:
            reason = "local_ambiguity_guard"
        elif any(marker in canonical for marker in ("/", "、", "**")):
            reason = "composite_canonical"
        elif contains_cjk and len(variant) == 1:
            reason = "single_cjk_form"
        # v0.4 第五节只收录已确认的人物 ASR 错识，不再仅因前后是中文而拦截。
        # 本地高歧义、单字、复合目标和英文单词边界防护仍然优先。
        elif (not is_confirmed_person_asr
              and contains_cjk and len(variant) <= 2
              and (is_cjk(before) or is_cjk(after))):
            reason = "short_form_inside_cjk_context"
        elif not contains_cjk and (is_ascii_word(before) or is_ascii_word(after)):
            reason = "inside_ascii_token"

        if reason:
            key = (variant, canonical, reason)
            stats["ambiguous"][key] = stats["ambiguous"].get(key, 0) + 1
            return variant

        key = (variant, canonical)
        stats["terms"][key] = stats["terms"].get(key, 0) + 1
        return canonical

    return pattern.sub(replace, text)


def clean_oral_line(text, first_content_line, stats):
    if first_content_line:
        match = LEADING_FILLER.match(text)
        if match and match.end() > match.start():
            stats["leading_fillers_removed"] += len(re.findall(r"[嗯啊呃额]", match.group(0)))
            text = text[match.end():]

    def compact_filler(match):
        stats["repeated_fillers_compacted"] += max(
            1, len(re.findall(r"[嗯啊呃额]", match.group(0))) - 1
        )
        return match.group(1)

    def compact_stutter(match):
        stats["obvious_stutters_collapsed"] += len(match.group(0)) - 1
        return match.group(1)

    text = REPEATED_FILLER.sub(compact_filler, text)
    text = OBVIOUS_STUTTER.sub(compact_stutter, text)
    return text


def clean_transcript(transcript, mappings, mapping_scopes):
    lines = transcript.splitlines()
    original_headers = [line for line in lines if SPEAKER_HEADER.match(line)]
    if not original_headers:
        raise ValueError("逐字稿未识别到 Speaker/说话人时间戳段落，已阻止入库")

    term_stats = {"terms": {}, "ambiguous": {}}
    oral_stats = {
        "leading_fillers_removed": 0,
        "repeated_fillers_compacted": 0,
        "obvious_stutters_collapsed": 0,
    }
    cleaned_lines = []
    in_segment = False
    first_content_line = False

    for line in lines:
        if SPEAKER_HEADER.match(line):
            cleaned_lines.append(line)
            in_segment = True
            first_content_line = True
            continue
        if not in_segment or not line.strip():
            cleaned_lines.append(line)
            continue
        cleaned = apply_terms(line, mappings, mapping_scopes, term_stats)
        cleaned = clean_oral_line(cleaned, first_content_line, oral_stats)
        cleaned_lines.append(cleaned)
        first_content_line = False

    cleaned = "\n".join(cleaned_lines)
    if transcript.endswith("\n"):
        cleaned += "\n"
    cleaned_headers = [line for line in cleaned.splitlines() if SPEAKER_HEADER.match(line)]
    if cleaned_headers != original_headers:
        raise ValueError("说话人或时间戳结构发生变化，已阻止入库")

    term_changes = [
        {"from": source, "to": target, "count": count}
        for (source, target), count in sorted(term_stats["terms"].items())
    ]
    ambiguous = [
        {"form": source, "candidate": target, "reason": reason, "count": count}
        for (source, target, reason), count in sorted(term_stats["ambiguous"].items())
    ]
    return cleaned, original_headers, term_changes, ambiguous, oral_stats


def sha256(value):
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--glossary", required=True)
    args = parser.parse_args()

    payload = json.loads(Path(args.input).read_text(encoding="utf-8"))
    transcript = str(payload.get("transcript") or "")
    if not transcript.strip():
        raise SystemExit("逐字稿为空，已阻止入库")
    mappings, mapping_scopes, conflicts, protected = parse_glossary(args.glossary)
    cleaned, headers, term_changes, ambiguous, oral_stats = clean_transcript(
        transcript, mappings, mapping_scopes
    )
    if not cleaned.strip():
        raise SystemExit("清洗结果为空，已阻止入库")

    result = {
        "status": "passed",
        "cleaning_skill": "minutes-cleaner",
        "cleaning_version": VERSION,
        "processed_at": dt.datetime.now(dt.timezone.utc).isoformat(),
        "minute_token": str(payload.get("minute_token") or ""),
        "cleaned_transcript": cleaned,
        "source_sha256": sha256(transcript),
        "cleaned_sha256": sha256(cleaned),
        "segment_count": len(headers),
        "speaker_headers_preserved": True,
        "term_change_count": sum(item["count"] for item in term_changes),
        "term_changes": term_changes,
        "oral_change_count": sum(oral_stats.values()),
        "oral_changes": oral_stats,
        "ambiguous_preserved_count": sum(item["count"] for item in ambiguous),
        "ambiguous_preserved": ambiguous,
        "glossary_conflict_count": len(conflicts),
        "protected_form_count": len(protected),
    }
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    if output.exists():
        raise SystemExit(f"refuse to overwrite existing file: {output}")
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(output)


if __name__ == "__main__":
    main()
